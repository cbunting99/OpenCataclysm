-- Update the runeforge object with a valid display ID
UPDATE gameobject_template SET displayid = 299 WHERE entry = 190557;

-- Creates the invisible runeforge objects in both ebon hold (map 609 and 0)
SET @GUID := 600700;
DELETE FROM gameobject WHERE guid >= @GUID AND guid <= @GUID+14;
INSERT INTO gameobject (guid, id, map, spawnMask, phaseMask, position_x, position_y, position_z, orientation, rotation0, rotation1, rotation2, rotation3, spawntimesecs, animprogress, state) VALUES 
(@GUID, 190557, 609, 1, 1, 2493.37, -5642.43, 420.649, 2.16421, 0, 0, 0.882948, 0.469471, 120, 0, 1),
(@GUID+1, 190557, 609, 1, 1, 2509.31, -5560.39, 420.65, -2.55402, 0, 0, -0.957154, 0.289578, 120, 0, 1),
(@GUID+2, 190557, 609, 1, 1, 2427.28, -5544.45, 420.65, -0.983229, 0, 0, -0.47205, 0.881572, 120, 0, 1),
(@GUID+3, 190557, 609, 1, 192, 2426.39, -5543.21, 420.64, -0.99, 0, 0, 0, 1, 120, 0, 1),
(@GUID+4, 190557, 609, 1, 35, 2426.39, -5543.21, 420.64, -0.99, 0, 0, 0, 1, 120, 0, 1),
(@GUID+5, 190557, 609, 1, 192, 2493.57, -5642.81, 420.64, 2.15, 0, 0, 0, 1, 120, 0, 1),
(@GUID+6, 190557, 609, 1, 4, 2493.57, -5642.81, 420.64, 2.15, 0, 0, 0, 1, 120, 0, 1),
(@GUID+7, 190557, 609, 1, 192, 2509.47, -5560.17, 420.64, -2.55, 0, 0, 0, 1, 120, 0, 1),
(@GUID+8, 190557, 609, 1, 35, 2493.57, -5642.81, 420.64, 2.15, 0, 0, 0, 1, 120, 0, 1),
(@GUID+9, 190557, 609, 1, 4, 2509.47, -5560.17, 420.64, -2.55, 0, 0, 0, 1, 120, 0, 1),
(@GUID+10, 190557, 609, 1, 35, 2509.47, -5560.17, 420.64, -2.55, 0, 0, 0, 1, 120, 0, 1),
(@GUID+11, 190557, 609, 1, 4, 2426.39, -5543.21, 420.64, -0.99, 0, 0, 0, 1, 120, 0, 1),
(@GUID+12, 190557, 0, 1, 1, 2427.28, -5544.45, 420.65, -0.983229, 0, 0, -0.47205, 0.881572, 120, 0, 1),
(@GUID+13, 190557, 0, 1, 1, 2509.31, -5560.39, 420.65, -2.55402, 0, 0, -0.957154, 0.289578, 120, 0, 1),
(@GUID+14, 190557, 0, 1, 1, 2493.37, -5642.43, 420.649, 2.16421, 0, 0, 0.882948, 0.469471, 120, 0, 1);

-- Quest 12779, An End to All Things - Autocomplete
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id = 12779;

-- Many creatures and quest givers
DELETE FROM creature WHERE id = 29110;
DELETE FROM creature WHERE guid >= 600300 and guid <= 600399;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES 
(600300, 29110, 609, 1, 1, 0, 0, 2312.04, -5741.28, 153.918, 3.82047, 300, 0, 0, 27890000, 0, 0, 0, 0, 0),
(600301, 29488, 609, 1, 128, 0, 0, 2350.32, -5693.07, 382.239, 4.40647, 300, 0, 0, 5066, 0, 0, 0, 0, 0),
(600302, 31084, 0, 1, 256, 0, 1, 2376.85, -5649.96, 382.437, 3.76597, 300, 0, 0, 11156000, 2129000, 0, 0, 134218496, 0),
(600303, 29480, 0, 1, 256, 0, 0, 2349.73, -5665.52, 382.241, 3.88324, 300, 0, 0, 232470, 0, 0, 0, 0, 0),
(600304, 29110, 609, 1, 128, 0, 0, 2349.65, -5667.98, 382.242, 3.77423, 300, 0, 0, 27890000, 0, 0, 0, 0, 0),
(600305, 29488, 609, 1, 128, 0, 0, 2324.85, -5658.95, 382.241, 3.57788, 300, 0, 0, 4906, 0, 0, 0, 0, 0),
(600306, 29501, 609, 1, 128, 0, 0, 2400.32, -5726.76, 153.923, 5.36891, 300, 0, 0, 5066, 0, 0, 0, 0, 0);

-- Quest 12801, The Light of Dawn - Autocomplete
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id = 12801;

-- Quest 13166, The battle for the Ebon Hold
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id = 13166;

-- Quest 12698, Stop the chain there, it doesn't work very well
update quest_template set Level = 90, MinLevel = 90 WHERE id = 12698;
update quest_template set NextQuestIdChain = 0 where NextQuestIdChain = 12698;
