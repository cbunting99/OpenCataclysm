-- Fix : Harrison Jones
DELETE FROM creature WHERE guid = 600009;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600009, 46978, 1, 1, 1, 0, 0, -10411.9, -231.985, 336.596, 4.56465, 300, 0, 0, 774900, 0, 0, 0, 0, 0);

-- Fix : Salhet
DELETE FROM creature WHERE guid = 600010;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600010, 46883, 1, 1, 1, 0, 1, -9982.77, -1240.29, 42.1056, 4.02258, 300, 0, 0, 44679, 4169, 0, 0, 0, 0);

-- Fix : Salhet V2
DELETE FROM creature WHERE guid = 600011;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600011, 48022, 1, 1, 1, 0, 0, -10362.1, -845.127, 129.238, 5.09071, 300, 0, 0, 84, 0, 0, 0, 0, 0);

-- Fix quest 27923: Smoke in their eyes
SET @SPELL := 88646; 
SET @GAMEOBJ_REWARD := 206682; 
SET @GAMEOBJ := 206682;
UPDATE `gameobject_template` SET `AIName`='SmartGameObjectAI' WHERE `entry` = @GAMEOBJ; 
DELETE FROM `smart_scripts` WHERE `entryorguid` = @GAMEOBJ AND `source_type`=1; 
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, 
`event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, 
`action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
(@GAMEOBJ,1,0,1,8,0,100,1,@SPELL,0,0,0,33,@GAMEOBJ_REWARD,0,0,0,0,0,7,0,0,0,0,0,0,0,'Bale of Hay - On Spell Hit - Give credit for quest 27923'),
(@GAMEOBJ,1,1,0,61,0,100,1,0,0,0,0,41,2000,0,0,0,0,0,1,0,0,0,0,0,0,0, 'Bale of Hay - Despawn after 2 second'); 

-- Sand Covered Heiroglyphs
UPDATE gameobject_template SET flags = 0 WHERE entry = 205874;

-- Uldum Survivor
UPDATE creature_template SET type = 4, type_flags = 0, faction_A = 834, faction_H = 834, IconName = '' WHERE entry = 45715;

-- Trooper Uniform
DELETE FROM `creature_loot_template` WHERE `entry` = 47220 AND `item` = 62789;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(47220, 62789, -100, 1, 0, 1, 1);

-- Quest - 27905 - Tailgunner! - Autocomplete
update quest_template set flags = 8, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0 WHERE id = 27905;

-- Quest - 27993 - Take it to 'Em! - Autocomplete
update quest_template set flags = 8, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0 WHERE id = 27993;

-- Quest - 27922 - Traitors! - Autocomplete
update quest_template set flags = 65536 WHERE id = 27922;

-- Quest - 28501 - The Defense of Nahom - Autocomplete
update quest_template set flags = 65536 WHERE id = 28501;

-- Fix : Itesh
DELETE FROM creature WHERE guid = 600012;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600012, 49943, 657, 1, 1, 0, 0, -328.098, 9.0766, 626.979, 2.59785, 300, 0, 0, 5971, 0, 0, 0, 0, 0);

-- Fix : Grand Vizier Ertan
DELETE FROM creature WHERE guid = 600013;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600013, 43878, 657, 1, 1, 0, 0, -721.686, 5.20662, 635.672, 5.4999, 300, 0, 0, 450000, 225100, 0, 0, 0, 0);

-- Elaborate Disc
UPDATE gameobject_template SET flags = 0 WHERE entry = 205266;

-- Decrepit Skeleton
UPDATE gameobject_template SET flags = 0 WHERE entry = 205540;

-- Tol'Vir Grave
UPDATE gameobject_template SET flags = 0 WHERE entry = 207409;

-- Fix : Siamat
DELETE FROM creature WHERE guid = 600014;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600014, 44819, 755, 1, 1, 0, 0, -10985.4, -1369.11, 10.807, 2.34673, 300, 0, 0, 2074850, 32585, 0, 0, 0, 0);

-- Uldum - MinLevel = 80
UPDATE quest_template SET minlevel = 80 WHERE minlevel = 83;

-- Tormented Tomb-Robber, needs to be hostile
UPDATE creature_template SET faction_A = 834, faction_H = 834 WHERE entry = 45765;

-- Fix : Harrison Jones
DELETE FROM creature WHERE guid = 600015;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600015, 45180, 1, 1, 1, 0, 0, -9210.26, -1561.57, 65.4522, 0.0129464, 300, 0, 0, 774900, 0, 0, 0, 0, 0);

-- Quest - 27922 - Traitors! - Autocomplete
update quest_template set flags = 65536 WHERE id = 27922;

-- Quest 27196 - On to Something
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0 WHERE id = 27196;

-- Quest 27511 - The Thrill of Discovery
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 27511;

-- Quest 27141 - Premature Explosionation
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 27141;

-- Quest 27431 - Tipping the balance
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 27431;

-- Quest 27624 - After the fall
DELETE FROM `gameobject_loot_template` WHERE `entry` = 34760 AND `item` = 61975;
DELETE FROM `gameobject_loot_template` WHERE `entry` = 34760 AND `item` = 61044;
DELETE FROM `gameobject_loot_template` WHERE `entry` = 34760 AND `item` = 61977;
INSERT INTO `gameobject_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(34760, 61975, -100, 1, 0, 1, 1),
(34760, 61044, -100, 1, 0, 1, 1),
(34760, 61977, -100, 1, 0, 1, 1);

-- Quest 27669 Do the honors
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 27669;

-- Quest #27541 Lessons From  the Past
DELETE FROM `creature_loot_template` WHERE `entry` = 45874 AND `item` = 61929;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(45874, 61929, -100, 1, 0, 1, 1);

-- Schnottz Scout, needs to be hostile
UPDATE creature_template SET modelid1 = 34892, faction_A = 834, faction_H = 834, gossip_menu_id = 0, npcflag = 0, unit_flags2 = 2048, unit_flags = 0, dynamicflags = 0, type = 7, type_flags = 0, lootid = 45874, VehicleId = 0  WHERE entry = 45874;
UPDATE creature SET curhealth = 50 WHERE id = 45874;

-- Colossus of the moon, needs to be hostile
UPDATE creature_template SET faction_A = 834, faction_H = 834 WHERE entry = 46042;

-- Colossus of the Sun, needs to be hostile
UPDATE creature_template SET faction_A = 834, faction_H = 834 WHERE entry = 46041;

-- Fix : Harrison Jones
DELETE FROM creature WHERE guid = 600016;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600016, 45296, 1, 1, 1, 0, 0, -9186, -1556.51, -172.559, 6.26872, 300, 0, 0, 774900, 0, 0, 0, 0, 0);

-- Fix : Harrison Jones
DELETE FROM creature WHERE guid = 600017;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600017, 44860, 1, 1, 1, 0, 0, -8952.47, -1549.9, 94.4543, 3.15462, 300, 0, 0, 105950, 0, 0, 0, 0, 0);

-- Fix : Harrison Jones
DELETE FROM creature WHERE guid = 600018;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600018, 48034, 1, 1, 1, 0, 0, -9426.06, -1511.32, 66.7761, 1.43803, 300, 0, 0, 105950, 0, 0, 0, 0, 0);

-- Fix : Colossus of the moon
DELETE FROM creature WHERE id = 46042;
DELETE FROM creature WHERE guid = 600019;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600019, 46042, 1, 1, 1, 0, 0, -9588.57, -115.241, 97.2698, 2.58863, 300, 0, 0, 107362, 0, 0, 0, 0, 0);

-- Fix : Colossus of the sun
DELETE FROM creature WHERE id = 46041;
DELETE FROM creature WHERE guid = 600020;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600020, 46041, 1, 1, 1, 0, 0, -9719.56, -12.2935, 87.062, 4.15156, 300, 0, 0, 107362, 0, 0, 0, 0, 0);

-- Titanic Guardian, needs to be hostile
UPDATE creature_template SET faction_A = 834, faction_H = 834, gossip_menu_id = 0, npcflag = 0, unit_flags = 0, unit_flags2 = 0, dynamicflags = 0, type = 6, type_flags = 0, lootid = 47032, VehicleId = 0  WHERE entry = 47032;

-- Quest 28277 - Salhet the tactician
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 28277;

-- Quest 27778 - Wacking the Wisbon
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 27778;

-- Quest 27779 - Gnomebliteration
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 27779;

-- Quest 28250 - Theiving little puckers
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 28250;

-- Quest #27541 Lessons From  the Past
DELETE FROM `creature_loot_template` WHERE `entry` = 45949 AND `item` = 61376;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(45949, 61376, -100, 1, 0, 1, 1);

-- Creature 50401 - Titan Mechanism
DELETE FROM creature WHERE guid = 600021;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600021, 50401, 1, 1, 1, 0, 0, -10414.6, -382.534, 223.749, 3.43355, 300, 0, 0, 4979, 0, 0, 0, 0, 0);

-- Update all creature damage for standard mobs
UPDATE creature_template SET mindmg = 1000.666, maxdmg = 1400.666, attackpower = 1550.666, minrangedmg = 750.666, maxrangedmg = 1100.666, rangedattackpower = 500.666 WHERE mindmg = 0 AND minlevel in (82, 83) AND rank = 0;
UPDATE creature_template SET mindmg = 1200.666, maxdmg = 1600.666, attackpower = 1750.666, minrangedmg = 900.666, maxrangedmg = 1300.666, rangedattackpower = 650.666 WHERE mindmg = 0 AND minlevel in (84, 85) AND rank = 0;
UPDATE creature_template SET mindmg = 2500.666, maxdmg = 3200.666, attackpower = 3500.666, minrangedmg = 1800.666, maxrangedmg = 2600.666, rangedattackpower = 1000.666 WHERE mindmg = 0 AND minlevel in (86, 87) AND rank = 0;
UPDATE creature_template SET mindmg = 5000.666, maxdmg = 6400.666, attackpower = 7000.666, minrangedmg = 4000.666, maxrangedmg = 5500.666, rangedattackpower = 2000.666 WHERE mindmg = 0 AND minlevel in (88, 89, 90) AND rank = 0;

-- Update all creature damage for elite mobs
UPDATE creature_template SET mindmg = 4000.666, maxdmg = 6000.666, attackpower = 6000.666, minrangedmg = 3000.666, maxrangedmg = 5000.666, rangedattackpower = 5000.666 WHERE mindmg = 0 AND minlevel in (82, 83) AND rank in (1, 2, 4);
UPDATE creature_template SET mindmg = 5000.666, maxdmg = 7500.666, attackpower = 7500.666, minrangedmg = 4000.666, maxrangedmg = 6000.666, rangedattackpower = 6000.666 WHERE mindmg = 0 AND minlevel in (84, 85) AND rank in (1, 2, 4);
UPDATE creature_template SET mindmg = 10000.666, maxdmg = 15000.666, attackpower = 15000.666, minrangedmg = 8000.666, maxrangedmg = 12000.666, rangedattackpower = 12000.666 WHERE mindmg = 0 AND minlevel in (86) AND rank in (1, 2, 4);
UPDATE creature_template SET mindmg = 20000.666, maxdmg = 30000.666, attackpower = 30000.666, minrangedmg = 16000.666, maxrangedmg = 24000.666, rangedattackpower = 24000.666 WHERE mindmg = 0 AND minlevel in (87) AND rank in (1, 2, 4);
UPDATE creature_template SET mindmg = 40000.666, maxdmg = 60000.666, attackpower = 60000.666, minrangedmg = 32000.666, maxrangedmg = 48000.666, rangedattackpower = 48000.666 WHERE mindmg = 0 AND minlevel in (88, 89, 90) AND rank in (1, 2, 4);

-- Update all creature damage for boss mobs
UPDATE creature_template SET mindmg = 10000.666, maxdmg = 14000.666, attackpower = 15500.666, minrangedmg = 7500.666, maxrangedmg = 11000.666, rangedattackpower = 15000.666 WHERE mindmg = 0 AND minlevel in (82, 83) AND rank = 3;
UPDATE creature_template SET mindmg = 12000.666, maxdmg = 16000.666, attackpower = 17500.666, minrangedmg = 9000.666, maxrangedmg = 13000.666, rangedattackpower = 17500.666 WHERE mindmg = 0 AND minlevel in (84, 85) AND rank = 3;
UPDATE creature_template SET mindmg = 25000.666, maxdmg = 32000.666, attackpower = 35000.666, minrangedmg = 18000.666, maxrangedmg = 26000.666, rangedattackpower = 35000.666 WHERE mindmg = 0 AND minlevel in (86) AND rank = 3;
UPDATE creature_template SET mindmg = 50000.666, maxdmg = 64000.666, attackpower = 70000.666, minrangedmg = 40000.666, maxrangedmg = 55000.666, rangedattackpower = 70000.666 WHERE mindmg = 0 AND minlevel in (87) AND rank = 3;
UPDATE creature_template SET mindmg = 100000.666, maxdmg = 128000.666, attackpower = 140000.666, minrangedmg = 80000.666, maxrangedmg = 110000.666, rangedattackpower = 140000.666 WHERE mindmg = 0 AND minlevel in (88, 89, 90) AND rank = 3;

-- Creature 47159 - Commander Schnottz
DELETE FROM creature WHERE guid = 600022;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600022, 47159, 1, 1, 1, 0, 0, -10679.4, 927.368, 26.2312, 3.30002, 300, 0, 0, 4913, 4454, 0, 0, 0, 0);

-- Fix Quest : Make yourself useful
UPDATE quest_template SET requiredNpcOrGo1 = 47291 WHERE Id = 27969;

-- Creature 47201 - Desert Fox
DELETE FROM creature WHERE guid = 600023;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600023, 47201, 1, 1, 1, 0, 0, -10961.3, -264.239, 9.30777, 1.19514, 300, 0, 0, 61733, 0, 0, 0, 0, 0);
UPDATE creature_template SET faction_A = 1881, faction_H = 1881, lootID = 47201 WHERE entry = 47201;
DELETE FROM `creature_loot_template` WHERE `entry` = 47201 AND `item` = 62777;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(47201, 62777, -100, 1, 0, 1, 1);

-- Quest 27990 - Battlezone
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 27990;

-- Quest 27950 - Gobbles!
update quest_template set RequiredNpcOrGo1 = 47255, RequiredNpcOrGoCount1 = 1, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, flags = 8 WHERE id = 27950;
update creature_template SET faction_A = 188, faction_H = 188 WHERE entry = 47255;
DELETE FROM creature_involvedrelation WHERE id = 47159 AND quest = 27950;
INSERT INTO creature_involvedrelation (id, quest) VALUES (47159, 27950);

-- Quest 28187 - Missed Me By Zhat Much!
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 28187;

-- Quest 28267 - Firing Squad
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 28267;

-- Sullah
update creature_template_addon set auras = '' where entry = 48203;

-- Quest 28274 Two Tents
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 28274;

-- Creature 47940 - Commander Schnottz
DELETE FROM creature WHERE guid = 600024;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600024, 47940, 1, 1, 1, 0, 0, -10670.7, 928.714, 26.3814, 3.30779, 300, 0, 0, 77490, 4454, 0, 0, 0, 0);

-- Creature 47255 - Gobbles
DELETE FROM creature WHERE guid = 600025;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600025, 47255, 1, 1, 1, 0, 0, -10697.9, 928.023, 26.6558, 0.122994, 300, 0, 0, 42, 0, 0, 0, 0, 0);

-- Creature 47940 - Commander Schnottz
DELETE FROM creature WHERE guid = 600026;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600026, 47972, 1, 1, 1, 0, 0, -10637.1, 1042.14, 25.7543, 1.87441, 300, 0, 0, 77490, 4454, 0, 0, 0, 0);

-- Creature 47980 - Captain Cork
DELETE FROM creature WHERE guid = 600027;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600027, 47980, 1, 1, 1, 0, 0, -10880.9, 901.513, 18.6547, 2.92681, 300, 0, 0, 64496, 0, 0, 0, 0, 0);

-- Creature 48162 - Harrison Jones
DELETE FROM creature WHERE guid = 600028;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600028, 48162, 1, 1, 1, 0, 0, -10514.3, 991.328, 43.6857, 1.21731, 300, 0, 0, 774900, 0, 0, 0, 0, 0);

-- Creature 48186 - Harrison Jones
DELETE FROM creature WHERE guid = 600029;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600029, 48186, 1, 1, 1, 0, 0, -8342.79, 768.189, 152.434, 2.52106, 300, 0, 0, 774900, 0, 0, 0, 0, 0);

-- Creature 48431 - Sullah
DELETE FROM creature WHERE guid = 600030;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600030, 48431, 1, 1, 1, 0, 0, -8929.04, 606.946, 151.224, 2.6035, 300, 0, 0, 774900, 0, 0, 0, 0, 0);

-- Fix Quest : Unlimited Potential, kill Cavorting Pygmy
UPDATE quest_template SET requiredNpcOrGo1 = 51217 WHERE Id = 28351;

-- Fix Quest : Camel Tow, kill Wild Camel
UPDATE quest_template SET requiredNpcOrGo1 = 51193 WHERE Id = 28352;

-- Quest 28367 Shroud of the Makers
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 28367;

-- Quest 28403 Bad Datas
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 28403;

-- Titanic Guardian, needs to be hostile
UPDATE creature_template SET faction_A = 834, faction_H = 834, gossip_menu_id = 0, npcflag = 0, unit_flags = 0, unit_flags2 = 0, dynamicflags = 0, type = 6, type_flags = 0, lootid = 48437, VehicleId = 0  WHERE entry = 48437;

-- Creature 48528 - Harrison Jones
DELETE FROM creature WHERE guid = 600031;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600031, 48528, 1, 1, 1, 0, 0, -8864.83, 202.366, 147.252, 1.03807, 300, 0, 0, 774900, 0, 0, 0, 0, 0);

-- Creature 48558 - Harrison Jones
DELETE FROM creature WHERE guid = 600032;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600032, 48558, 1, 1, 1, 0, 0, -8987.55, 27.5256, -17.96, 0.244821, 300, 0, 0, 774900, 0, 0, 0, 0, 0);

-- Creature 48437 - Titanic Guardian
DELETE FROM creature WHERE guid = 600033;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600033, 48437, 1, 1, 1, 0, 0, -9013.09, -38.655, -21.7553, 1.02628, 300, 0, 0, 232470, 0, 0, 0, 0, 0);

-- Spawn some Obsidium Deposit in Uldum since it cannot be found elsewhere
DELETE FROM gameobject WHERE guid >= 600000 AND guid <= 6000031;
INSERT INTO gameobject (guid, id, map, spawnMask, phaseMask, position_x, position_y, position_z, orientation, rotation0, rotation1, rotation2, rotation3, spawntimesecs, animprogress, state) VALUES 
(600000, 202736, 1, 1, 1, -9002.94, 182.64, 150.3, 4.67, 0, 0, 0, 1, 120, 255, 1),
(600001, 202736, 1, 1, 1, -9429.87, 126.24, 128.23, 4.05, 0, 0, 0, 1, 120, 255, 1),
(600002, 202736, 1, 1, 1, -8313.52, -124.97, 234.44, 0.91, 0, 0, 0, 1, 120, 255, 1),
(600003, 202736, 1, 1, 1, -8458.81, 280.66, 155.78, 3.13, 0, 0, 0, 1, 120, 255, 1),
(600004, 202736, 1, 1, 1, -8406.92, 470.12, 185.02, 3, 0, 0, 0, 1, 120, 255, 1),
(600005, 202736, 1, 1, 1, -8512.67, 886.44, 169.94, 3.25, 0, 0, 0, 1, 120, 255, 1),
(600006, 202736, 1, 1, 1, -8753.66, 436.44, 304.45, 4.06, 0, 0, 0, 1, 120, 255, 1),
(600007, 202736, 1, 1, 1, -9333.35, 802.27, 241.67, 1.58, 0, 0, 0, 1, 120, 255, 1),
(600008, 202736, 1, 1, 1, -9546.42, 363.92, 148.76, 4.73, 0, 0, 0, 1, 120, 255, 1),
(600009, 202736, 1, 1, 1, -9748.28, 813.22, 172.23, 4.98, 0, 0, 0, 1, 120, 255, 1),
(600010, 202736, 1, 1, 1, -10093.42, 1057.98, 148.91, 1.62, 0, 0, 0, 1, 120, 255, 1),
(600011, 202736, 1, 1, 1, -10420.59, 1429.38, 108.21, 1.69, 0, 0, 0, 1, 120, 255, 1),
(600012, 202736, 1, 1, 1, -10953.10, 335.46, 10.65, 5.45, 0, 0, 0, 1, 120, 255, 1),
(600013, 202736, 1, 1, 1, -10652.84, -225.95, 150.35, 0.09, 0, 0, 0, 1, 120, 255, 1),
(600014, 202736, 1, 1, 1, -10269.03, -222.40, 279.87, 4.04, 0, 0, 0, 1, 120, 255, 1),
(600015, 202736, 1, 1, 1, -10424.06, -761.48, 223.03, 3.33, 0, 0, 0, 1, 120, 255, 1),
(600016, 202736, 1, 1, 1, -11042.39, -934.00, 189.40, 3.71, 0, 0, 0, 1, 120, 255, 1),
(600017, 202736, 1, 1, 1, -10770.16, -1669.88, 11.55, 5.59, 0, 0, 0, 1, 120, 255, 1),
(600018, 202736, 1, 1, 1, -10343.87, -1320.03, 46.93, 5.64, 0, 0, 0, 1, 120, 255, 1),
(600019, 202736, 1, 1, 1, -10814.50, -1956.98, 169.30, 2.57, 0, 0, 0, 1, 120, 255, 1),
(600020, 202736, 1, 1, 1, -10972.22, -2246.19, 159.77, 2.07, 0, 0, 0, 1, 120, 255, 1),
(600021, 202736, 1, 1, 1, -10552.54, -2634.84, 7.21, 1.24, 0, 0, 0, 1, 120, 255, 1),
(600022, 202736, 1, 1, 1, -10042.26, -2393.39, 18.75, 1.25, 0, 0, 0, 1, 120, 255, 1),
(600023, 202736, 1, 1, 1, -9516.30, -1894.27, 111.72, 1.48, 0, 0, 0, 1, 120, 255, 1),
(600024, 202736, 1, 1, 1, -9103.53, -1811.35, 130.24, 1.81, 0, 0, 0, 1, 120, 255, 1),
(600025, 202736, 1, 1, 1, -8625.56, -1571.99, 184.07, 5.60, 0, 0, 0, 1, 120, 255, 1),
(600026, 202736, 1, 1, 1, -8507.99, -1112.86, 317.04, 2.73, 0, 0, 0, 1, 120, 255, 1),
(600027, 202736, 1, 1, 1, -8691.88, -555.73, 188.20, 1.03, 0, 0, 0, 1, 120, 255, 1),
(600028, 202736, 1, 1, 1, -9795.72, -1416.99, 65.49, 0.55, 0, 0, 0, 1, 120, 255, 1),
(600029, 202736, 1, 1, 1, -9920.16, -56.54, 60.39, 6.13, 0, 0, 0, 1, 120, 255, 1),
(600030, 202736, 1, 1, 1, -10050.48, 426.73, 29.31, 6.09, 0, 0, 0, 1, 120, 255, 1),
(600031, 202736, 1, 1, 1, -10332.19, 868.59, 57.48, 1.55, 0, 0, 0, 1, 120, 255, 1);

-- Quest 28497 Fire From the Sky
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 28497;

-- Quest 28736 Fire From the Sky (Daily)
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 28736;

-- Obsidian Colossus, needs to be hostile
UPDATE creature_template SET faction_A = 834, faction_H = 834, gossip_menu_id = 0, npcflag = 0, unit_flags = 0, unit_flags2 = 0, dynamicflags = 0, type = 6, type_flags = 0, lootid = 46646, VehicleId = 0  WHERE entry = 46646;

-- Creature 48621 - Sullah
DELETE FROM creature WHERE guid = 600034;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600034, 48621, 1, 1, 1, 0, 0, -9095.27, -162.778, 142.436, 4.18738, 300, 0, 0, 774900, 0, 0, 0, 0, 0);

-- Creature 48698 - Harrison Jones
DELETE FROM creature WHERE guid = 600035;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600035, 48698, 1, 1, 1, 0, 0, -8260.17, -120.064, 320.205, 2.6205, 300, 0, 0, 774900, 0, 0, 0, 0, 0);

-- Creature 47158 - Harrison Jones
DELETE FROM creature WHERE guid = 600036;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600036, 47158, 1, 1, 1, 0, 0, -8676.51, 208.714, 338.857, 4.98852, 300, 0, 0, 774900, 0, 0, 0, 0, 0);

-- Quest 28612 Harrison Jones and the temple of Uldum
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 28612;

-- Quest 28622 Three if by Air
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 28622;

-- Quest 28633 The Coffer of Promises
update quest_template set RequiredItemId1 = 0, RequiredItemCount1 = 0 WHERE id = 28633;

-- Quest 27707 Neferset Prison
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 27707;
DELETE FROM creature_involvedrelation WHERE id = 46136 AND quest = 27707;
INSERT INTO creature_involvedrelation (id, quest) VALUES (46136, 27707);

-- Tahet, needs to be hostile
UPDATE creature_template SET faction_A = 834, faction_H = 834, gossip_menu_id = 0, npcflag = 0, unit_flags = 0, unit_flags2 = 0, dynamicflags = 0, type = 6, type_flags = 0, lootid = 46496, VehicleId = 0  WHERE entry = 46496;

-- All the Scarabs from Obelish of the Stars
update creature_template_addon set auras = '' where entry = 46129;
update creature_template_addon set auras = '' where entry = 46128;
update creature_template_addon set auras = '' where entry = 46127;
update creature_template_addon set auras = '' where entry = 46126;
update creature_template_addon set auras = '' where entry = 46129;
update creature_template_addon set auras = '' where entry = 46128;
update creature_template_addon set auras = '' where entry = 46127;
delete from creature_loot_template where entry IN (46126, 46127, 46128, 46129);
update creature_template set lootid = 0 where entry IN (46126, 46127, 46128, 46129);

-- Quest 27627 - Just a fancy coackroaches
DELETE FROM creature_involvedrelation WHERE id = 45296 AND quest = 27627;
INSERT INTO creature_involvedrelation (id, quest) VALUES (45296, 27627);
DELETE FROM creature_questrelation WHERE id = 45296 AND quest = 27627;
INSERT INTO creature_questrelation (id, quest) VALUES (45296, 27627);
UPDATE quest_template SET flags = 8 WHERE id = 27627;

-- Quest 28486 Salhet's Gambit
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 28486;

-- Quest 27940 - Dirty Birds
DELETE FROM creature_involvedrelation WHERE id = 49248 AND quest = 27940;
INSERT INTO creature_involvedrelation (id, quest) VALUES (49248, 27940);
DELETE FROM creature_questrelation WHERE id = 49248 AND quest = 27940;
INSERT INTO creature_questrelation (id, quest) VALUES (49248, 27940);
UPDATE quest_template SET flags = 8 WHERE id = 27940;

-- Quest 27187 - Mangy Hiena
DELETE FROM creature_involvedrelation WHERE id = 47959 AND quest = 27187;
INSERT INTO creature_involvedrelation (id, quest) VALUES (47959, 27187);
DELETE FROM creature_questrelation WHERE id = 47959 AND quest = 27187;
INSERT INTO creature_questrelation (id, quest) VALUES (47959, 27187);
UPDATE quest_template SET flags = 8 WHERE id = 27187;

-- Many creatures and quest givers
DELETE FROM creature WHERE guid >= 600037 and guid <= 600058;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES 
(600037, 49151, 1, 1, 1, 0, 0, -8837.39, 371.465, 352.934, 4.16777, 300, 0, 0, 774900, 0, 0, 0, 0, 0),
(600038, 49204, 1, 1, 1, 0, 0, -9300.06, 422.546, 242.795, 1.5476, 300, 0, 0, 77490, 0, 0, 0, 0, 0),
(600039, 49203, 1, 1, 1, 0, 0, -9296.86, 422.451, 242.796, 1.66296, 300, 0, 0, 774900, 0, 0, 0, 0, 0),
(600040, 49248, 1, 1, 1, 0, 0, -10811.5, -335.035, 4.64437, 2.56615, 300, 0, 0, 77490, 0, 0, 0, 0, 0),
(600041, 49351, 1, 1, 1, 0, 0, -10812, -337.177, 4.92718, 2.88548, 300, 0, 0, 77490, 0, 0, 0, 0, 0),
(600042, 46135, 1, 1, 1, 0, 1, -9755.11, -913.391, 57.1899, 3.83736, 300, 0, 0, 53681, 0, 0, 0, 0, 0),
(600043, 47959, 1, 1, 1, 0, 0, -9433.15, -965.101, 111.012, 3.13838, 300, 0, 0, 53681, 0, 0, 0, 0, 0),
(600044, 46129, 1, 1, 1, 0, 0, -9116.53, -1550.11, -170.91, 3.1305, 300, 0, 0, 26841, 0, 0, 0, 0, 0),
(600045, 49345, 1, 1, 1, 0, 0, -10737.2, -827.863, 91.0212, 2.81632, 300, 0, 0, 44679, 4169, 0, 0, 0, 0),
(600046, 48428, 1, 1, 1, 0, 0, -9030.37, -19.1494, 143.419, 3.24829, 300, 0, 0, 2324700, 4454, 0, 0, 0, 0),
(600047, 47967, 1, 1, 1, 0, 0, -10663.7, 1091.6, 25.3099, 3.72291, 300, 0, 0, 30951, 3994, 0, 0, 0, 0),
(600048, 46129, 1, 1, 1, 0, 0, -9143.27, -1517.37, -170.91, 3.7111, 300, 0, 0, 26841, 0, 0, 0, 0, 0),
(600049, 46127, 1, 1, 1, 0, 0, -9191.42, -1632.6, -172.559, 6.01232, 300, 0, 0, 26841, 0, 0, 0, 0, 0),
(600050, 49523, 1, 1, 1, 0, 1, -8260.83, -123.878, 320.42, 2.76469, 300, 0, 0, 5971, 0, 0, 0, 0, 0),
(600051, 44833, 1, 1, 1, 0, 1, -8927.28, -2257.67, 8.87805, 1.68657, 300, 0, 0, 35967, 0, 0, 0, 0, 0),
(600052, 46873, 1, 1, 1, 0, 1, -10995.1, -1251.59, 13.2429, 3.11599, 300, 0, 0, 35967, 0, 0, 0, 0, 0),
(600053, 39788, 644, 1, 1, 0, 1, -499.103, 193.208, 66.4808, 3.12196, 300, 0, 0, 2074850, 0, 0, 0, 0, 0),
(600054, 39587, 644, 1, 1, 0, 1, -505.425, 72.4414, 81.8417, 1.559, 300, 0, 0, 1659880, 300000, 0, 0, 0, 0),
(600055, 39731, 644, 1, 1, 0, 1, -505.502, -49.6127, 81.843, 1.56292, 300, 0, 0, 1659880, 0, 0, 0, 0, 0),
(600056, 39732, 644, 1, 1, 0, 1, -504.208, -274.005, 141.074, 1.57865, 300, 0, 0, 1659880, 32585, 0, 0, 0, 0),
(600057, 39378, 644, 1, 1, 0, 1, -507.757, -695.087, 139.966, 1.57175, 300, 0, 0, 2074850, 0, 0, 0, 0, 0),
(600058, 48082, 1, 1, 1, 0, 0, -9753.15, -940.44, 106.743, 3.51999, 120, 0, 0, 774900, 0, 0, 0, 0, 0);

-- Quest 27003 Easy Money
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 27003;

-- Instance mobs needs to be selectable, no script so they can fight correctly and no vehicle so they move ok
UPDATE creature_template SET unit_flags = 32832, ScriptName = '', VehicleId = 0 WHERE entry = 40808;
UPDATE creature_template SET unit_flags = 32832, ScriptName = '', VehicleId = 0 WHERE entry = 40787;
UPDATE creature_template SET unit_flags = 32832, ScriptName = '', VehicleId = 0 WHERE entry = 40311;
UPDATE creature_template SET unit_flags = 32832, ScriptName = '', VehicleId = 0 WHERE entry = 39788;
UPDATE creature_template SET unit_flags = 32832, ScriptName = '', VehicleId = 0 WHERE entry = 39731;
UPDATE creature_template SET unit_flags = 32832, ScriptName = '', VehicleId = 0 WHERE entry = 44577;
UPDATE creature_template SET unit_flags = 32832, ScriptName = '', VehicleId = 0 WHERE entry = 39378;

-- Quest  Penetrating their defenses
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 28746;

-- Spawn some Heartblossom in Uldum since it cannot be found elsewhere
DELETE FROM gameobject WHERE guid >= 600032 AND guid <= 6000061;
INSERT INTO gameobject (guid, id, map, spawnMask, phaseMask, position_x, position_y, position_z, orientation, rotation0, rotation1, rotation2, rotation3, spawntimesecs, animprogress, state) VALUES 
(600032, 202750, 1, 1, 1, -9313.79, -808.65, 120.82, 0, 0, 0, 0, 1, 120, 255, 1),
(600033, 202750, 1, 1, 1, -9243.99, -569.68, 117.95, 1, 0, 0, 0, 1, 120, 255, 1),
(600034, 202750, 1, 1, 1, -9157.47, -237.75, 136.95, 2, 0, 0, 0, 1, 120, 255, 1),
(600035, 202750, 1, 1, 1, -8501.21, 253.60, 149.32, 3, 0, 0, 0, 1, 120, 255, 1),
(600036, 202750, 1, 1, 1, -8454.15, 567.42, 149.51, 4, 0, 0, 0, 1, 120, 255, 1),
(600037, 202750, 1, 1, 1, -8422.18, 825.60, 149.92, 5, 0, 0, 0, 1, 120, 255, 1),
(600038, 202750, 1, 1, 1, -8667.30, 657.19, 149.51, 0, 0, 0, 0, 1, 120, 255, 1),
(600039, 202750, 1, 1, 1, -8979.04, 516.56, 149.35, 1, 0, 0, 0, 1, 120, 255, 1),
(600040, 202750, 1, 1, 1, -10697.45, 1428.84, 1.21, 2, 0, 0, 0, 1, 120, 255, 1),
(600041, 202750, 1, 1, 1, -10733.90, 1033.01, 0.3, 3, 0, 0, 0, 1, 120, 255, 1),
(600042, 202750, 1, 1, 1, -11075.57, -112.63, 0.34, 4, 0, 0, 0, 1, 120, 255, 1),
(600043, 202750, 1, 1, 1, -11579.30, -1225.66, 1.49, 5, 0, 0, 0, 1, 120, 255, 1),
(600044, 202750, 1, 1, 1, -11352.76, -1301.41, 0.70, 0, 0, 0, 0, 1, 120, 255, 1),
(600045, 202750, 1, 1, 1, -10968.68, -1206.44, 4.28, 1, 0, 0, 0, 1, 120, 255, 1),
(600046, 202750, 1, 1, 1, -10630.29, -1316.24, 2.16, 2, 0, 0, 0, 1, 120, 255, 1),
(600047, 202750, 1, 1, 1, -10902.59, -1581.01, 0.51, 3, 0, 0, 0, 1, 120, 255, 1),
(600048, 202750, 1, 1, 1, -11218.39, -1820.36, 2.25, 4, 0, 0, 0, 1, 120, 255, 1),
(600049, 202750, 1, 1, 1, -11038.98, -2305.32, 3.33, 5, 0, 0, 0, 1, 120, 255, 1),
(600050, 202750, 1, 1, 1, -9897.34, -2888.41, 1.70, 0, 0, 0, 0, 1, 120, 255, 1),
(600051, 202750, 1, 1, 1, -9734.50, -1650.75, 13.73, 1, 0, 0, 0, 1, 120, 255, 1),
(600052, 202750, 1, 1, 1, -10545.61, -1216.31, 44.03, 2, 0, 0, 0, 1, 120, 255, 1),
(600053, 202750, 1, 1, 1, -10202.37, -1158.08, 43.35, 3, 0, 0, 0, 1, 120, 255, 1),
(600054, 202750, 1, 1, 1, -9948.42, -957.22, 43.53, 4, 0, 0, 0, 1, 120, 255, 1),
(600055, 202750, 1, 1, 1, -10088.60, -1159.02, 43.60, 5, 0, 0, 0, 1, 120, 255, 1),
(600056, 202750, 1, 1, 1, -9761.02, -702.75, 99.87, 0, 0, 0, 0, 1, 120, 255, 1),
(600057, 202750, 1, 1, 1, -9510.81, -1209.91, 101.56, 1, 0, 0, 0, 1, 120, 255, 1),
(600058, 202750, 1, 1, 1, -9180.81, -1152.12, 127.67, 2, 0, 0, 0, 1, 120, 255, 1),
(600059, 202750, 1, 1, 1, -8931.76, -1054.05, 154.24, 3, 0, 0, 0, 1, 120, 255, 1),
(600060, 202750, 1, 1, 1, -8777.54, -1154.60, 155.87, 4, 0, 0, 0, 1, 120, 255, 1),
(600061, 202750, 1, 1, 1, -8628.92, -1332.32, 210.49, 5, 0, 0, 0, 1, 120, 255, 1);

-- Create the portal to Uldum in Stormwind
DELETE FROM gameobject WHERE guid >= 6000062 AND guid <= 6000062;
INSERT INTO gameobject (guid, id, map, spawnMask, phaseMask, position_x, position_y, position_z, orientation, rotation0, rotation1, rotation2, rotation3, spawntimesecs, animprogress, state) VALUES 
(6000062, 207695, 0, 1, 1, -8232.88, 415.98, 117.47, 0.12, 0, 0, 0, 1, 120, 255, 1);

-- Create the portal to Stormwind in Uldum
DELETE FROM gameobject WHERE guid >= 6000063 AND guid <= 6000063;
INSERT INTO gameobject (guid, id, map, spawnMask, phaseMask, position_x, position_y, position_z, orientation, rotation0, rotation1, rotation2, rotation3, spawntimesecs, animprogress, state) VALUES 
(6000063, 208227, 1, 1, 1, -9466.31, -941.62, 112.97, 4.74, 0, 0, 0, 1, 120, 255, 1);

-- Update the Peregrine Statue creature to remove it from the map since it bugs the players
UPDATE creature SET map = 30000 WHERE id = 46644;

-- Update the movement Id and aura for Obsidian Colossus so he can charge the players
UPDATE creature_template SET movementId = 0 WHERE entry = 46646;
UPDATE creature_template_addon SET auras = '' WHERE entry = 46646;

-- NPC 47048 - Temple of Uldum Sensor - Needs to be invisible to players
UPDATE creature_template SET flags_extra = 128 WHERE entry = 47048;

