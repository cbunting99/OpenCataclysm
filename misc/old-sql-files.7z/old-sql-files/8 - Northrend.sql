-- *** FIXES FOR HOWLING FJORD START ***

-- Creates the missing game objects for Northrend
DELETE FROM gameobject WHERE guid >= 600800 AND guid <= 600899;
INSERT INTO gameobject (guid, id, map, spawnMask, phaseMask, position_x, position_y, position_z, orientation, rotation0, rotation1, rotation2, rotation3, spawntimesecs, animprogress, state) VALUES 
(600800, 186468, 571, 1, 1, 1625.39, -3348.63, 79.64, 0, 0, 0, 0, 1, 120, 0, 1),
(600801, 186468, 571, 1, 1, 1603.1, -3345.15, 75.4, 0, 0, 0, 0, 1, 120, 0, 1),
(600802, 186468, 571, 1, 1, 1644.47, -3332.7, 81.03, 0, 0, 0, 0, 1, 120, 0, 1),
(600803, 186468, 571, 1, 1, 1661.44, -3311.68, 81.27, 0, 0, 0, 0, 1, 120, 0, 1),
(600804, 186468, 571, 1, 1, 1689.72, -3282.17, 79.33, 0, 0, 0, 0, 1, 120, 0, 1),
(600805, 186468, 571, 1, 1, 1685.02, -3257.62, 74.69, 0, 0, 0, 0, 1, 120, 0, 1),
(600806, 186404, 571, 1, 1, 1701.35, -3312.46, 80.55, 0, 0, 0, 0, 1, 120, 0, 1),
(600807, 186404, 571, 1, 1, 1713.92, -3329.86, 81.31, 0, 0, 0, 0, 1, 120, 0, 1),
(600808, 186404, 571, 1, 1, 1723.78, -3341.87, 81.91, 0, 0, 0, 0, 1, 120, 0, 1),
(600809, 186404, 571, 1, 1, 1742.7, -3349.72, 81.52, 0, 0, 0, 0, 1, 120, 0, 1),
(600810, 186404, 571, 1, 1, 1763.44, -3352.42, 81.35, 0, 0, 0, 0, 1, 120, 0, 1),
(600811, 186404, 571, 1, 1, 1787.11, -3338.24, 83.18, 0, 0, 0, 0, 1, 120, 0, 1),
(600812, 186404, 571, 1, 1, 1784.47, -3321.69, 84.86, 0, 0, 0, 0, 1, 120, 0, 1),
(600813, 186404, 571, 1, 1, 1772.69, -3307.6, 87.17, 0, 0, 0, 0, 1, 120, 0, 1),
(600814, 186404, 571, 1, 1, 1753.22, -3298.67, 81.79, 0, 0, 0, 0, 1, 120, 0, 1),
(600815, 186404, 571, 1, 1, 1739.68, -3296.67, 81.44, 0, 0, 0, 0, 1, 120, 0, 1),
(600816, 186404, 571, 1, 1, 1714.99, -3299.36, 80.52, 0, 0, 0, 0, 1, 120, 0, 1),
(600817, 186404, 571, 1, 1, 1694.84, -3285.35, 79.52, 0, 0, 0, 0, 1, 120, 0, 1),
(600818, 186404, 571, 1, 1, 1677.25, -3272.13, 77.09, 0, 0, 0, 0, 1, 120, 0, 1),
(600819, 186404, 571, 1, 1, 1645.92, -3253.19, 71.08, 0, 0, 0, 0, 1, 120, 0, 1),
(600820, 186404, 571, 1, 1, 1625.02, -3279.47, 74.19, 0, 0, 0, 0, 1, 120, 0, 1),
(600821, 186404, 571, 1, 1, 1604.1, -3212.9, 75.22, 0, 0, 0, 0, 1, 120, 0, 1),
(600822, 186404, 571, 1, 1, 1645.12, -3355.73, 81.46, 0, 0, 0, 0, 1, 120, 0, 1),
(600823, 186404, 571, 1, 1, 1654.48, -3396.88, 80.55, 0, 0, 0, 0, 1, 120, 0, 1);

-- Spawn some NPCs and quest givers
DELETE FROM creature WHERE guid >= 600400 and guid <= 600404;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES 
(600400, 24029, 571, 1, 1, 0, 1, 2628.38, -3539.61, 162.148, 2.17273, 120, 0, 0, 9291, 3231, 0, 0, 0, 0),
(600401, 25026, 571, 1, 1, 0, 1, 114.658, -3698.49, 0.853066, 2.13244, 120, 0, 0, 8982, 0, 0, 0, 0, 0),
(600402, 25026, 571, 1, 1, 0, 1, 120.775, -3708.47, 2.22592, 5.68243, 120, 0, 0, 8982, 0, 0, 0, 0, 0),
(600403, 24277, 571, 1, 1, 0, 0, 2709.43, -3039.89, 96.8052, 5.37224, 120, 0, 0, 13937, 0, 0, 0, 0, 0),
(600404, 24019, 571, 1, 1, 0, 0, 2824.08, -3603.34, 245.716, 4.05206, 120, 0, 0, 18582, 0, 0, 0, 0, 0);

-- Fix some quests in Howling Fjord with Smart Scripts
UPDATE `creature_template` SET `AIName`='SmartAI' WHERE `entry` IN (23725, 23876, 45188, 51087); 
UPDATE `gameobject_template` SET `AIName`='SmartGameObjectAI' WHERE `entry` IN (186718); 
DELETE FROM `smart_scripts` WHERE `entryorguid` IN (23725, 23876, 45188, 51087) AND `source_type`=0; 
DELETE FROM `smart_scripts` WHERE `entryorguid` IN (186718) AND `source_type`=1; 
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, 
`event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, 
`action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
(23725,0,0,0,8,0,100,1,49859,0,0,0,33,24345,0,0,0,0,0,7,0,0,0,0,0,0,0, 'Stone Giant - On spell hit - Give kill credit for quest 11352'),
(23876,0,0,1,8,0,100,1,43354,0,0,0,33,51087,0,0,0,0,0,7,0,0,0,0,0,0,0, 'Killed Spore - On spell hit - Give kill credit for quest 11319'),
(23876,0,1,0,61,0,100,1,0,0,0,0,41,1000,0,0,0,0,0,1,0,0,0,0,0,0,0, 'Killed Spore - Despawn after 1 seconds'),
(45188,0,0,0,8,0,100,1,43692,0,0,0,33,24381,0,0,0,0,0,7,0,0,0,0,0,0,0, 'Broken Tablet - On spell hit - Give kill credit for quest 11358'),
(51087,0,0,1,8,0,100,1,43354,0,0,0,33,51087,0,0,0,0,0,7,0,0,0,0,0,0,0, 'Killed Spore - On spell hit - Give kill credit for quest 11319'),
(51087,0,1,0,61,0,100,1,0,0,0,0,41,1000,0,0,0,0,0,1,0,0,0,0,0,0,0, 'Killed Spore - Despawn after 1 seconds'),
(186718,1,0,0,8,0,100,1,43692,0,0,0,33,24381,0,0,0,0,0,7,0,0,0,0,0,0,0, 'Broken Tablet - On spell hit - Give kill credit for quest 11358');

-- Update many quests to autocomplete
update quest_template set SpecialFlags = 0, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 
WHERE id IN (11202, 11332, 11343, 11358, 11390, 11418, 11421, 11429, 11436, 11470, 11485, 11489, 11491, 11494, 11495, 12032);
UPDATE quest_template set flags = 65536 WHERE Id IN (11343, 11429, 11436, 11485, 11489, 11491, 11495);

-- Update the Wrecked Crab Trap, Battered Journal & Amberseed so they can be looted
UPDATE gameobject_template SET flags = 0 WHERE entry = 188364;
UPDATE gameobject_template SET flags = 32 WHERE entry = 188261;
UPDATE gameobject_template SET flags = 0 WHERE entry = 188667;

-- Update the creature templates so they can be attacked correctly
UPDATE creature_template SET unit_flags = 32768, unit_flags2 = 2048, npcflag = 0, faction_A = 1954, faction_H = 1954, lootid = 23674 WHERE entry = 23674;
UPDATE creature_template SET unit_flags = 0, unit_flags2 = 2048, npcflag = 0, faction_A = 31, faction_H = 31, lootid = 23977 WHERE entry = 23977;
UPDATE creature_template SET unit_flags = 32768, unit_flags2 = 2048, npcflag = 3, faction_A = 1924, faction_H = 1924, lootid = 24261 WHERE entry = 24261;
UPDATE creature_template SET unit_flags = 0, unit_flags2 = 2048, npcflag = 0, faction_A = 14, faction_H = 14, lootid = 24277 WHERE entry = 24277;
UPDATE creature_template SET unit_flags = 32768, unit_flags2 = 2048, npcflag = 0, faction_A = 834, faction_H = 834, lootid = 26510 WHERE entry = 26510;
UPDATE creature_template SET unit_flags = 0, unit_flags2 = 2048, npcflag = 0, faction_A = 35, faction_H = 35, lootid = 45188 WHERE entry = 45188;

-- Give the correct quest loot for some NPCs
DELETE FROM `creature_loot_template` WHERE `entry` = 24216 AND `item` = 33545;
DELETE FROM `creature_loot_template` WHERE `entry` = 24788 AND `item` = 34116;
DELETE FROM `creature_loot_template` WHERE `entry` = 26503 AND `item` = 35803;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(24216, 33545, -100, 1, 0, 1, 1),
(24788, 34116, -100, 1, 0, 1, 1),
(26503, 35803, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 24216 WHERE `entry` = 24216; 
UPDATE `creature_template` SET `lootid` = 24788 WHERE `entry` = 24788; 
UPDATE `creature_template` SET `lootid` = 26503 WHERE `entry` = 26503; 

-- Repair the flight master in Valgarde Keep
UPDATE creature_template SET gossip_menu_id = 0 WHERE entry = 23736;

-- Fix the Quest 11289 - Guided by Honor
DELETE FROM smart_scripts WHERE (entryorguid=24189 AND source_type=0 AND id=1);
INSERT INTO smart_scripts (entryorguid, source_type, id, link, event_type, event_phase_mask, event_chance, event_flags, event_param1, event_param2, event_param3, event_param4, action_type, action_param1, action_param2, action_param3, action_param4, action_param5, action_param6, target_type, target_param1, target_param2, target_param3, target_x, target_y, target_z, target_o, comment) VALUES 
(24189, 0, 1, 0, 19, 0, 100, 0, 11289, 0, 0, 0, 85, 43228, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, "Ares - On target quest accepted 11289 - Cast spell Guided by the Oathbound QC");

-- Creates a procedure to make sure we are compatible with the latest version of trinity 4.3.4
drop procedure if exists HOWLING_FJORD;
delimiter //
create procedure HOWLING_FJORD() 
begin

	-- Fix quest 11436 let's go surfing now so it can be completed
	if EXISTS( SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'world' AND TABLE_NAME='creature_involvedrelation') then 
		DELETE FROM creature_involvedrelation WHERE quest = 11436;
		INSERT INTO creature_involvedrelation (id, quest) VALUES (24634, 11436);
	end if;
	if EXISTS( SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'world' AND TABLE_NAME='creature_questender') then 
		DELETE FROM creature_questender WHERE quest = 11436;
		INSERT INTO creature_questender (id, quest) VALUES (24634, 11436);
	end if;

end;
// 
delimiter ;

-- Execute the procedure
call HOWLING_FJORD();
drop procedure HOWLING_FJORD;

-- *** FIXES FOR HOWLING FJORD END ***


-- *** FIXES FOR ICECROWN ***

-- Pit of Saron - Update Scourgelord Tyrannus so he can be attacked, old value was 33554496
UPDATE creature_template SET unit_flags = 64 WHERE entry = 36658;

-- *** FIXES FOR ICECROWN END ***


-- *** FIXES FOR SHOLAZAR BASIN START ***

-- Update many quests to autocomplete
update quest_template set SpecialFlags = 0, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 
WHERE id IN (12589, 12536);

-- Update some creatures so they attack back, old value was 105
UPDATE creature_template SET VehicleId = 0 WHERE name = 'Shardhorn Rhino' or name = 'Farunn';

-- Spawn some NPCs and quest givers
DELETE FROM creature WHERE guid >= 600405 and guid <= 600409;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES 
(600405, 28092, 1, 1, 1, 0, 0, -6191.34, -1222.04, -160.868, 4.83648, 120, 0, 0, 12600, 0, 0, 0, 0, 0),
(600406, 28601, 1, 1, 1, 0, 0, -6028.08, -1249.02, -146.764, 3.05433, 120, 0, 0, 1, 0, 0, 0, 0, 0),
(600407, 28214, 571, 1, 1, 0, 1, 5242.71, 4514.19, -82.2134, 0.0884336, 120, 0, 0, 11379, 0, 0, 0, 0, 0),
(600408, 28105, 571, 1, 1, 0, 0, 6714.14, 5130.91, -19.4075, 1.85584, 120, 0, 0, 11379, 0, 0, 0, 0, 0),
(600409, 28106, 571, 1, 1, 0, 0, 4874.32, 5908.86, -40.5269, 4.6041, 120, 0, 0, 117700, 3809, 0, 0, 0, 0);

-- Quest Burning to Help, need to set only the kill for the quest to work
UPDATE quest_template SET RequiredNpcOrGo1 = 28003, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, ObjectiveText1 = '' WHERE Id = 12683;

-- Quest 12536 - Auto call the aera explored to complete the quest
UPDATE `creature_template` SET `AIName`= 'SmartAI' WHERE `entry`= 28082;
DELETE FROM `smart_scripts` WHERE `entryorguid` = 28082;
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, `event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, `action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES
(28082, 0, 0, 0, 19,  0, 100, 0, 12536, 0, 0, 0, 15, 12536, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 'High-Shaman Rakjak - On Quest Accept - Call Areaexplored');

-- Quest 12570 needs to have the correct prequisite quest
UPDATE quest_template SET PrevQuestId = 12540 WHERE Id = 12570;

-- Aura for creature 28114 - Mistcaller Soo-gan cause a SQL error, we remove it to see the creature
UPDATE creature_template_addon SET auras = '' WHERE entry = 28114;

-- NPC 28105 - Warlord Tartek - Needs to be hostile to be killed
UPDATE creature_template SET faction_A = 2061, faction_H = 2061 WHERE entry = 28105;

-- Quest 12578 - The Angry Gorloc - Auto call the aera explored to complete the quest
UPDATE `creature_template` SET `AIName`= 'SmartAI' WHERE `entry`= 28027;
DELETE FROM `smart_scripts` WHERE `entryorguid` = 28027;
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, `event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, `action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES
(28027, 0, 0, 0, 19,  0, 100, 0, 12578, 0, 0, 0, 15, 12578, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 'High-Oracle Soo-say - On Quest Accept - Call Areaexplored');

-- Creates the missing game objects for Northrend
DELETE FROM gameobject WHERE guid >= 600824 AND guid <= 600824;
INSERT INTO gameobject (guid, id, map, spawnMask, phaseMask, position_x, position_y, position_z, orientation, rotation0, rotation1, rotation2, rotation3, spawntimesecs, animprogress, state) VALUES 
(600824, 190777, 571, 1, 1, 5612.80, 3794.98, -90.512, 5.5432, 0, 0, 0, 1, 120, 0, 1);

-- Give the Stormwatcher's Head loot to the Stormwatcher
DELETE FROM `creature_loot_template` WHERE `entry` = 28877 AND `item` = 39667;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(28877, 39667, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 28877 WHERE `entry` = 28877; 

-- *** FIXES FOR SHOLAZAR BASIN END ***

