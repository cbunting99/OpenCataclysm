-- *** FIXES FOR DUN MOROGH ***

-- Quest #24475 fix : All the Other Stuff.  Add the quest loot to the timber wolf, young wolf and boar
DELETE FROM `creature_loot_template` WHERE `entry` = 708 AND `item` = 49747;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES (708, 49747, -39, 1, 0, 1, 1);
DELETE FROM `creature_loot_template` WHERE `entry` = 705 AND `item` = 49748;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES (705, 49748, -64, 1, 0, 1, 1);
DELETE FROM `creature_loot_template` WHERE `entry` = 704 AND `item` = 49748;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES (704, 49748, -70, 1, 0, 1, 1);


-- Quest #24486 fix : Make Hay While the Sun Shines.  Add the Priceless Rockjaw Artifact loot to the Rockjaw Scavenger so you can complete the quest
DELETE FROM `creature_loot_template` WHERE `entry` = 37105 AND `item` = 49751;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES (37105, 49751, -90, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 37105 WHERE `entry` = 37105; 


-- Quest #384 fix: Adding the tender boar meat to the crag boar, the 41% rate is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 1125 AND `item` = 60496;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES (1125, 60496, -41, 1, 0, 1, 1);
-- Quest #384 fix: Last gossip_menu_id was 1297 but it was preventing players from trading with the innkeeper and setting their heartstone in that region
UPDATE `creature_template` SET `gossip_menu_id` = 0 WHERE `entry` = 1247; 


-- Quest #25997 fix: Adding Dark Iron Attack Plans
DELETE FROM `creature_loot_template` WHERE `entry` = 6124 AND `item` = 56264;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES (6124, 56264, -100, 1, 0, 1, 1);


-- Quest #412 Operation Recombobulation - fix: Adding the Gyromechanic Gear, the drop rate is from wow head
DELETE FROM `creature_loot_template` WHERE `entry` = 41146 AND `item` = 3084;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(41146, 3084, -91, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 41146 WHERE `entry` = 41146; 



-- *** FIXES FOR LOCH MODAN ***

-- Quest #26845 fix: Adding the Foreman Sharpsneer's Head
DELETE FROM `creature_loot_template` WHERE `entry` = 44198 AND `item` = 60404;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES (44198, 60404, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 44198 WHERE `entry` = 44198; 


-- Quest #26842 fix: Adding Mosshide Ear
DELETE FROM `creature_loot_template` WHERE `entry` = 44162 AND `item` = 60402;
DELETE FROM `creature_loot_template` WHERE `entry` = 44161 AND `item` = 60402;
DELETE FROM `creature_loot_template` WHERE `entry` = 45384 AND `item` = 60402;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(44162, 60402, -100, 1, 0, 1, 1),
(44161, 60402, -100, 1, 0, 1, 1),
(45384, 60402, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 44162 WHERE `entry` = 44162; 
UPDATE `creature_template` SET `lootid` = 44161 WHERE `entry` = 44161; 
UPDATE `creature_template` SET `lootid` = 45384 WHERE `entry` = 45384; 


-- Quest #26928 fix: Adding Murloc Scent Gland, the drop rates are from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 44176 AND `item` = 60511;
DELETE FROM `creature_loot_template` WHERE `entry` = 44292 AND `item` = 60511;
DELETE FROM `creature_loot_template` WHERE `entry` = 45401 AND `item` = 60511;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(44176, 60511, -45, 1, 0, 1, 1),
(44292, 60511, -38, 1, 0, 1, 1),
(45401, 60511, -30, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 44176 WHERE `entry` = 44176; 
UPDATE `creature_template` SET `lootid` = 44292 WHERE `entry` = 44292; 
UPDATE `creature_template` SET `lootid` = 45401 WHERE `entry` = 45401; 


-- Quest #26929 fix: Adding Intact Crocolisk Jaw, the 44% drop rates is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 1693 AND `item` = 57131;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(1693, 57131, -44, 1, 0, 1, 1);


-- Quest #26860 fix: Adding Bear Rump, the 56% drop rates is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 1186 AND `item` = 60497;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(1186, 60497, -56, 1, 0, 1, 1);


-- Quest #27031 Wing Nut - fix: Adding the Pristine Flight Feather, the 34% drop rate is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 44628 AND `item` = 60792;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) 
VALUES (44628, 60792, -34, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 44628 WHERE `entry` = 44628; 


-- Quest #27028 Hornet Hunting - fix: Adding the Glassy Hornet Wing, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 44620 AND `item` = 60754;
DELETE FROM `creature_loot_template` WHERE `entry` = 45402 AND `item` = 60754;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(44620, 60754, -41, 1, 0, 1, 1),
(45402, 60754, -32, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 44620 WHERE `entry` = 44620; 
UPDATE `creature_template` SET `lootid` = 45402 WHERE `entry` = 45402; 


-- Quest #27030 Foxtails by the handful - fix: Adding the Fluffy Fox Tail, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 44635 AND `item` = 60755;
DELETE FROM `creature_loot_template` WHERE `entry` = 45380 AND `item` = 60755;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(44635, 60755, -81, 1, 0, 1, 1),
(45380, 60755, -53, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 44635 WHERE `entry` = 44635; 
UPDATE `creature_template` SET `lootid` = 45380 WHERE `entry` = 45380; 



-- *** FIXES FOR THE WETLANDS ***

-- Quest #25800 When Life Gives You Crabs - fix: Adding the Meaty Crawler Claw, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 44116 AND `item` = 56013;
DELETE FROM `creature_loot_template` WHERE `entry` = 41295 AND `item` = 56013;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(44116, 56013, -43, 1, 0, 1, 1),
(41295, 56013, -36, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 44116 WHERE `entry` = 44116; 
UPDATE `creature_template` SET `lootid` = 41295 WHERE `entry` = 41295;


-- Quest #25723 Thresh Out of Luck - fix: Adding the Threshadon Chunk, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 41137 AND `item` = 55232;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(41137, 55232, -94, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 41137 WHERE `entry` = 41137; 


-- Quest #25849 When Archaeology Attacks - fix: Adding the Fossilized Bone, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 41388 AND `item` = 56083;
DELETE FROM `creature_loot_template` WHERE `entry` = 44226 AND `item` = 56083;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(41388, 56083, -68, 1, 0, 1, 3),
(44226, 56083, -5, 1, 0, 1, 3);
UPDATE `creature_template` SET `lootid` = 41388 WHERE `entry` = 41388; 
UPDATE `creature_template` SET `lootid` = 44226 WHERE `entry` = 44226; 


-- Quest #25853 Tooling Around - fix: Adding the Archaeologist's Tools
DELETE FROM `gameobject_loot_template` WHERE `entry` = 29626 AND `item` = 56082;
INSERT INTO `gameobject_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(29626, 56082, -100, 1, 0, 1, 1);



-- *** FIXES FOR THE HINTERLANDS ***

-- Quest #26490 (Alliance) & #26283 (Horde) Prime Slime - fix: Adding the Direglob Sample
DELETE FROM `creature_loot_template` WHERE `entry` = 42592 AND `item` = 58082;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(42592, 58082, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 42592 WHERE `entry` = 42592; 



-- *** FIXES FOR NPC TRAINERS ***

-- Fix the fishing trainers so the players can train beyond 75.  356 is the correct skill ID for fishing.
UPDATE `npc_trainer` SET `reqskill` = 356 WHERE `reqskill` = 365 AND `entry` = 200302;



-- *** FIXES FOR DARKSHORE ***

-- Quest #13521 Buzzbox 413 - fix: Adding the Corrupted Tide Crawler Flesh, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 32935 AND `item` = 44863;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(32935, 44863, -40, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 32935 WHERE `entry` = 32935; 
-- Quest #13521 Buzzbox 413 - fix: create the quest reward giver, the Buzzbox 413
DELETE FROM `gameobject_template` WHERE `entry` = 194105;
INSERT INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `size`, `data1`) VALUES (194105, 2, 356, 'Buzzbox 413', 1, 9477);
DELETE FROM `gameobject` WHERE `guid` = 194105 AND `id` = 2040;
INSERT INTO `gameobject` (`guid`, `id`, `map`, `spawnMask`, `phaseMask`, `position_x`, `position_y`, `position_z`, 
`orientation`, `rotation0`, `rotation1`, `rotation2`, `rotation3`, `spawntimesecs`, `animprogress`, `state`) VALUES 
(194105, 2040, 0, 1, 1, -935.522, -3939.23, 147.561, 2.60444, 0, 0, 0.96415, 0.265358, 300, 0, 1);


-- Quest #13528 Buzzbox 723 - fix: Adding the Corrupted Thistle Bear Guts, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 33905 AND `item` = 44913;
DELETE FROM `creature_loot_template` WHERE `entry` = 33009 AND `item` = 44913;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(33905, 44913, -35, 1, 0, 1, 1),
(33009, 44913, -32, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 33905 WHERE `entry` = 33905; 
UPDATE `creature_template` SET `lootid` = 33009 WHERE `entry` = 33009; 


-- Quest #13513 On the Brink - fix: Adding the Shatterspear Amulet, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 32860 AND `item` = 44942;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(32860, 44942, -83, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 32860 WHERE `entry` = 32860; 


-- Quest #13844 The Looting of Althalaxx - fix: create the Charred Book game object and its loot
DELETE FROM `gameobject_template` WHERE `entry` = 194787;
INSERT INTO `gameobject_template` (`entry`, `type`, `displayId`, `name`, `castBarCaption`, `flags`, `size`, `questItem1`, `data0`, `data1`) VALUES 
(194787, 3, 2530, 'Charred Book', 'Examining', 4, 1, 45944, 43, 24124);
DELETE FROM `gameobject_loot_template` WHERE `entry` = 24124 AND `item` = 45944;
INSERT INTO `gameobject_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(24124, 45944, -100, 1, 0, 1, 1);


-- Quest #13554 A Cure In The Dark - fix: Adding the Foul Ichor, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 33021 AND `item` = 44966;
DELETE FROM `creature_loot_template` WHERE `entry` = 33022 AND `item` = 44966;
DELETE FROM `creature_loot_template` WHERE `entry` = 33020 AND `item` = 44966;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(33021, 44966, -35, 1, 0, 1, 1),
(33022, 44966, -34, 1, 0, 1, 1),
(33020, 44966, -20, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 33021 WHERE `entry` = 33021; 
UPDATE `creature_template` SET `lootid` = 33022 WHERE `entry` = 33022; 
UPDATE `creature_template` SET `lootid` = 33020 WHERE `entry` = 33020; 



-- *** FIXES FOR DUN MOROGH - GNOME STARTING ZONE ***

-- Change the NPC: Torben Zapblast for SmartAI so he can use scripts like teleports, change the Icon and Flag so he can speak single gossip
UPDATE creature_template SET AIName = 'SmartAI', IconName = 'Speak', type_flags = 134221824 WHERE entry = 46293;
-- Assign the gossip menu to Torben Zapblast
DELETE FROM gossip_menu WHERE entry = 12104 AND text_id = 16995;
INSERT INTO gossip_menu (entry, text_id) VALUES (12104, 16995);
-- Update the gossip menu option to show the gossip option to leave gnomeragan
UPDATE gossip_menu_option SET option_id = 1, npc_option_npcflag = 1 WHERE menu_id = 12104 AND id = 1;
-- Create the telelport smart script so gnomes can exit their starting location
DELETE FROM smart_scripts WHERE entryorguid = 46293;
INSERT INTO smart_scripts (entryorguid, source_type, id, link, event_type, event_phase_mask, event_chance, event_flags, 
event_param1, event_param2, event_param3, event_param4, action_type, action_param1, action_param2, action_param3, 
action_param4, action_param5, action_param6, target_type, target_param1, target_param2, target_param3, target_x, target_y, target_z, target_o, comment)  
VALUES (46293, 0, 1, 0, 62, 0, 100, 0, 12104, 1, 0, 0, 62, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, -5201.2856, 477.5454, 388.471, 5.2577, 'Teleport');


-- Quest #26264 What's Left Behind - fix: Adding the Recovered Possession, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 42184 AND `item` = 57987;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(42184, 57987, -89, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 42184 WHERE `entry` = 42184; 


-- Quest #26285 Get Me Explosives Back! - fix: Adding the Stolen Powder Keg, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 42221 AND `item` = 58202;
DELETE FROM `creature_loot_template` WHERE `entry` = 42222 AND `item` = 58202;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(42221, 58202, -95, 1, 0, 1, 1),
(42222, 58202, -86, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 42221 WHERE `entry` = 42221; 
UPDATE `creature_template` SET `lootid` = 42222 WHERE `entry` = 42222; 



-- *** FIXES FOR THE WETLANDS ***


-- Quest #25722 Sedimentary, My Dear - fix: Adding the Flood Sediment Sample
DELETE FROM `gameobject_loot_template` WHERE `entry` = 29569 AND `item` = 55231;
INSERT INTO `gameobject_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(29569, 55231, -100, 1, 0, 1, 1);


-- Quest #25726 A Dumpy Job - fix: Adding the Dumpy Level, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 41145 AND `item` = 55234;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(41145, 55234, -9, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 41145 WHERE `entry` = 41145; 


-- Quest #25727 Drungeld Glowerglare - fix: Adding the Glowerglare's Beard
DELETE FROM `creature_loot_template` WHERE `entry` = 41151 AND `item` = 55988;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(41151, 55988, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 41151 WHERE `entry` = 41151; 



-- *** FIXES FOR THE SOUTERN BARRENS ***


-- Quest #24824 The Disturbed Earth - fix: Adding the Gargantapid's Poison Gland, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 37553 AND `item` = 50385;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(37553, 50385, -39, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 37553 WHERE `entry` = 37553; 



-- *** FIXES FOR TANARIS ***


-- Quest #25522 Gargantapid - fix: Adding the Gargantapid's Poison Gland
DELETE FROM `creature_loot_template` WHERE `entry` = 40581 AND `item` = 54855;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(40581, 54855, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 40581 WHERE `entry` = 40581; 


-- Quest #25521 I'm With Scorpid - fix: Adding the Duneclaw Stinger. the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 40656 AND `item` = 54856;
DELETE FROM `creature_loot_template` WHERE `entry` = 40717 AND `item` = 54856;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(40656, 54856, -49, 1, 0, 1, 1),
(40717, 54856, -48, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 40656 WHERE `entry` = 40656; 
UPDATE `creature_template` SET `lootid` = 40717 WHERE `entry` = 40717; 


-- Quest #24931 Gazer Tag - fix: Adding the Ocular Crystal, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 5420 AND `item` = 51793;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(5420, 51793, -40, 1, 0, 1, 1);



-- *** FIXES FOR WINTERSPRING ***

-- Quest #28530 Scalding Signs - fix: Adding the Suspicious Green Sludge, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 48767 AND `item` = 64449;
DELETE FROM `creature_loot_template` WHERE `entry` = 48768 AND `item` = 64449;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(48767, 64449, -44, 1, 0, 1, 1),
(48768, 64449, -41, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 48767 WHERE `entry` = 48767; 
UPDATE `creature_template` SET `lootid` = 48768 WHERE `entry` = 48768; 


-- Quest #28625 Chop Chop - fix: Adding the Fresh-Cut Frostwood
DELETE FROM `creature_loot_template` WHERE `entry` = 48952 AND `item` = 64587;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(48952, 64587, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 48952 WHERE `entry` = 48952; 


-- Quest #28610 Rubble Trouble - fix: Adding the Prime Rubble Chunk, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 48960 AND `item` = 64586;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(48960, 64586, -71, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 48960 WHERE `entry` = 48960; 


-- Quest #28837 Altered Beasts - fix: Adding the Mana-Addled Brain, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 49161 AND `item` = 66052;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(49161, 66052, -42, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 49161 WHERE `entry` = 49161; 


-- Quest #28537 In Pursuit of Shades - fix: Adding the Shard of the Spiritspeaker
DELETE FROM `creature_loot_template` WHERE `entry` = 48678 AND `item` = 64463;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(48678, 64463, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 48678 WHERE `entry` = 48678; 


-- Quest #28540 Doin' De E'ko Magic - fix: Adding the Rimepelt's Heart
DELETE FROM `creature_loot_template` WHERE `entry` = 48765 AND `item` = 64465;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(48765, 64465, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 48765 WHERE `entry` = 48765; 


-- Quest #28631 The Perfect Horns - fix: Adding the Icewhomp's Pristine Horns, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 49235 AND `item` = 64664;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(49235, 64664, -57, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 49235 WHERE `entry` = 49235; 


-- Quest #28840 Winterwater - fix: Adding the Winterwater, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 50251 AND `item` = 65903;
DELETE FROM `creature_loot_template` WHERE `entry` = 50250 AND `item` = 65903;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(50251, 65903, -28, 1, 0, 1, 1),
(50250, 65903, -24, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 50251 WHERE `entry` = 50251; 
UPDATE `creature_template` SET `lootid` = 50250 WHERE `entry` = 50250; 


-- Quest #28518 Legacy of the High Elves - fix: Adding the Memory of Zin-Malor
DELETE FROM `creature_loot_template` WHERE `entry` = 48740 AND `item` = 64441;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(48740, 64441, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 48740 WHERE `entry` = 48740; 


-- Quest #28479 The Ruins of Kel'Theril - fix: spawn the creature that gives the quest, the creature data is from Skyfire
DELETE FROM creature WHERE guid = 307142;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
307142, 48658, 1, 1, 1, 36232, 0, 6543.91, -4110.53, 663.446, 0.366519, 
300, 0, 0, 1962, 1982, 0, 0, 0, 0);


-- Quest Descendants of the Highborn - fix: spawn the creature that gives the quest
DELETE FROM creature WHERE guid = 600000;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600000, 48659, 1, 1, 1, 36232, 0, 6545.68, -4113.53, 663.78, 0.366519, 
300, 0, 0, 1962, 1982, 0, 0, 0, 0);


-- Quest Descendants of the High Elves - fix: spawn the creature that gives the quest
DELETE FROM creature WHERE guid = 600001;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600001, 48660, 1, 1, 1, 36232, 0, 6543.32, -4106.79, 662.95, 0.366519, 
300, 0, 0, 1962, 1982, 0, 0, 0, 0);


-- Quests Winterfall Activity & More Beads for Saffa, creates the loot and links the loot to the quest
DELETE FROM item_template WHERE entry = 600000;
INSERT INTO item_template (entry, class, subclass, name, displayid, Quality, Flags, FlagsExtra, BuyCount, BuyPrice, SellPrice, ItemLevel, stackable, description, bonding) VALUES 
(600000, 12, 0, 'Winterfall Spirit Beads', 1399, 1, 0, 8192, 1, 800, 200, 1, 250, 'These may be gathered for the Timbermaw furbolgs to earn their trust.', 1);
DELETE FROM creature_loot_template WHERE item = 600000;
INSERT INTO creature_loot_template (entry, item, ChanceOrQuestChance, lootmode, groupid, mincountOrRef, maxcount) VALUES 
(7438, 600000, 50, 1, 0, 1, 1),
(7439, 600000, 50, 1, 0, 1, 1),
(7440, 600000, 50, 1, 0, 1, 1),
(7441, 600000, 50, 1, 0, 1, 1),
(7442, 600000, 50, 1, 0, 1, 1),
(10738, 600000, 50, 1, 0, 1, 1),
(10916, 600000, 50, 1, 0, 1, 1);
UPDATE quest_template SET RequiredItemId1 = 600000 WHERE RequiredItemId1 = 21383;


-- Delete the Winterfall Ritual Totem from the loot, the quest that it gives is now obsolete
DELETE FROM creature_loot_template WHERE item = 20742;


-- Quest Winterfall Firewater needs to have a staring and ending point to work
DELETE FROM creature_involvedrelation WHERE id = 9298 AND quest = 28462;
INSERT INTO creature_involvedrelation (id, quest) VALUES
(9298, 28462);
DELETE FROM creature_questrelation WHERE id = 9298 AND quest = 28462;
INSERT INTO creature_questrelation (id, quest) VALUES
(9298, 28462);


-- Quest 28632 - Fresh From The Hills, adds the drop to complete the quest
UPDATE creature_template SET lootID = 49233 WHERE entry = 49233;
DELETE FROM creature_loot_template WHERE entry = 49233;
INSERT INTO creature_loot_template (entry, item, ChanceOrQuestChance, lootmode, groupid, mincountOrRef, maxcount) VALUES 
(49233, 64662, -100, 1, 0, 1, 1);


-- Quest #28722 - Yetiphobia - Autocomplete
UPDATE quest_template SET RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0 WHERE Id = 28722;


-- Quest #28841 - The Arcane Storm Within - Autocomplete
UPDATE quest_template SET RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0 WHERE Id = 28841;


-- Make this Trigger - NPC invisible to players, they show as chickens with rockets
UPDATE creature_template SET flags_extra = 128 WHERE entry IN (44775, 46464);


-- Quest 28838 & 28638 as incorrect flags the previous flags was 327688 <- extra 8
UPDATE quest_template SET flags = 32768 WHERE id iN (28638, 28838);


-- Quest 28638 - The Owls Have It - Set the NPC that ends the quest
DELETE FROM creature_involvedrelation WHERE id = 49537 AND quest = 28638;
INSERT INTO creature_involvedrelation (id, quest) VALUES
(49537, 28638);


-- Quest 28745 - Screechy Keen - Set the NPC that ends the quest
DELETE FROM creature_involvedrelation WHERE id = 49537 AND quest = 28745;
INSERT INTO creature_involvedrelation (id, quest) VALUES
(49537, 28745);


-- Quest 29032 - Get Them While They're Young - Switch the NPC so he can be killed and the quest completed
UPDATE creature_template SET unit_flags = 0, unit_flags2 = 2048, lootid = 51681 WHERE entry = 51681;
DELETE FROM `creature_loot_template` WHERE `entry` = 51681 AND `item` = 68638;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(51681, 68638, -100, 1, 0, 1, 1);


-- Quest 5201 - This quest gives 5 whiskers because the cub quest cannot be completed.  If the cub quests are corrected, this should be removed
UPDATE quest_template SET RewardItemId1 = 68644, RewardItemCount1 = 5 WHERE id = 5201;
DELETE FROM creature_questrelation WHERE id = 51677;


-- *** FIXES FOR THE WINTERSPRING END


-- *** FIXES FOR THE WAILING CAVERNS

-- Fix : Wailing Caverns - Add Lord Pythas
DELETE FROM creature WHERE guid = 600002;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600002, 3670, 43, 1, 1, 0, 0, -49.2486, 372.728, -59.5564, 3.51933, 300, 0, 0, 10825, 1470, 0, 0, 0, 0);



-- *** FIXES FOR ASHENVALE ***


-- Quest #25607 Ze Gnomecorder - fix: Adding the Filthy Goblin Technology, the drop % is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 34590 AND `item` = 55144;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(34590, 55144, -55, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 34590 WHERE `entry` = 34590; 

-- Quest #13979 The Goblin Braintrust - fix: Adding the Sploder's Head
DELETE FROM `creature_loot_template` WHERE `entry` = 34591 AND `item` = 46768;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(34591, 46768, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 34591 WHERE `entry` = 34591; 



-- *** FIXES FOR THE BLASTED LANDS ***


-- Quest #26159 (Alliance) & #25685 (Horde) The First Step - fix: Adding the Snickerfang Hyena Blood, the drop rate is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 5985 AND `item` = 55826;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) 
VALUES (5985, 55826, -69, 1, 0, 1, 1);
-- Quest #26159 (Alliance) & #25685 (Horde) The First Step - fix: Adding the Redstone Basilisk Blood, the drop rate is from wowhead
DELETE FROM `creature_loot_template` WHERE `entry` = 5990 AND `item` = 55827;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) 
VALUES (5990, 55827, -64, 1, 0, 1, 1);


-- Quest #26172 (Alliance) & #25690 (Horde) A Bloodmage's Gotta Eat Too - fix: Adding the Ashmane Steak, the drop rate is from wow head
DELETE FROM `creature_loot_template` WHERE `entry` = 5992 AND `item` = 55828;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(5992, 55828, -29, 1, 0, 1, 1);


-- Quest #25716 Cultists at our Doorstep - fix: Adding the Intact Shadowsworn Spell Focus, the drop rate is from wow head
DELETE FROM `creature_loot_template` WHERE `entry` = 42297 AND `item` = 57134;
DELETE FROM `creature_loot_template` WHERE `entry` = 42296 AND `item` = 57134;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(42297, 57134, -78, 1, 0, 1, 1),
(42296, 57134, -71, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 42297 WHERE `entry` = 42297; 
UPDATE `creature_template` SET `lootid` = 42296 WHERE `entry` = 42296; 


-- Quest #26165 (Alliance) & #25692 (Horde) The Vile Blood of Demons - fix: Adding the Vile Demonic Blood, the drop rate is from wow head
DELETE FROM `creature_loot_template` WHERE `entry` = 6011 AND `item` = 55991;
DELETE FROM `creature_loot_template` WHERE `entry` = 41253 AND `item` = 55991;
DELETE FROM `creature_loot_template` WHERE `entry` = 6010 AND `item` = 55991;
DELETE FROM `creature_loot_template` WHERE `entry` = 41166 AND `item` = 55991;
DELETE FROM `creature_loot_template` WHERE `entry` = 41165 AND `item` = 55991;
DELETE FROM `creature_loot_template` WHERE `entry` = 41164 AND `item` = 55991;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(6011, 55991, -36, 1, 0, 1, 1),
(41253, 55991, -33, 1, 0, 1, 1),
(6010, 55991, -32, 1, 0, 1, 1),
(41166, 55991, -16, 1, 0, 1, 1),
(41165, 55991, -16, 1, 0, 1, 1),
(41164, 55991, -11, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 6011 WHERE `entry` = 6011; 
UPDATE `creature_template` SET `lootid` = 41253 WHERE `entry` = 41253; 
UPDATE `creature_template` SET `lootid` = 6010 WHERE `entry` = 6010; 
UPDATE `creature_template` SET `lootid` = 41166 WHERE `entry` = 41166; 
UPDATE `creature_template` SET `lootid` = 41165 WHERE `entry` = 41165; 
UPDATE `creature_template` SET `lootid` = 41164 WHERE `entry` = 41164; 



-- *** FIXES FOR ELWYNN FOREST ***


-- Quest #26389 Blackrock Invasion - fix: Adding the Blackrock Orc Weapon
DELETE FROM `creature_loot_template` WHERE `entry` = 42937 AND `item` = 58361;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) 
VALUES (42937, 58361, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 42937 WHERE `entry` = 42937; 


-- Quest #26152 Wanted: James Clark - fix: Adding the James Clark's Head
DELETE FROM `creature_loot_template` WHERE `entry` = 13159 AND `item` = 57122;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) 
VALUES (13159, 57122, -100, 1, 0, 1, 1);


-- Quest #86 Pie for Billy - fix: Adding the Tender Boar Meat, the drop rates are from wow head
DELETE FROM `creature_loot_template` WHERE `entry` = 113 AND `item` = 60401;
DELETE FROM `creature_loot_template` WHERE `entry` = 524 AND `item` = 60401;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(113, 60401, -21, 1, 0, 1, 1),
(524, 60401, -12, 1, 0, 1, 1);



-- *** FIXES FOR DUSK WOOD ***


-- Quest #26707 A Deadly Vine - fix: Adding the Corpseweed, the drop rates are from wow head
DELETE FROM `creature_loot_template` WHERE `entry` = 43732 AND `item` = 60204;
DELETE FROM `creature_loot_template` WHERE `entry` = 45785 AND `item` = 60204;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(43732, 60204, -89, 1, 0, 1, 1),
(45785, 60204, -56, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 43732 WHERE `entry` = 43732; 
UPDATE `creature_template` SET `lootid` = 45785 WHERE `entry` = 45785; 


-- Quest #26677 Ghoulish Effigy - fix: Adding the Ghoul Rib, the drop rates are from wow head
DELETE FROM `creature_loot_template` WHERE `entry` = 1270 AND `item` = 884;
DELETE FROM `creature_loot_template` WHERE `entry` = 570 AND `item` = 884;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(1270, 884, -72, 1, 0, 1, 1),
(570, 884, -6, 1, 0, 1, 1);


-- Quest #26620 Seasoned Wolf Kabobs - fix: Adding the Wolf Skirt Steak, the drop rates are from wow head
DELETE FROM `creature_loot_template` WHERE `entry` = 43704 AND `item` = 60989;
DELETE FROM `creature_loot_template` WHERE `entry` = 521 AND `item` = 60989;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(43704, 60989, -31, 1, 0, 1, 1),
(521, 60989, -31, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 43704 WHERE `entry` = 43704; 


-- Quest #26623 Dusky Crab Cakes - fix: Adding the Dusky Lump, the drop rates is from wow head
DELETE FROM `creature_loot_template` WHERE `entry` = 217 AND `item` = 60988;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(217, 60988, -40, 1, 0, 1, 1);


-- Quest Delivery to Master Harris, Remove Aura so Oliver Harris is shown
UPDATE creature_template_addon SET auras = '' WHERE entry = 43730;


-- Monster Marl Wormthorn must be changed so players can fight him
UPDATE creature_template SET faction_A = 90, faction_H = 90, unit_flags = 0, type_flags = 0, type = 3 WHERE entry = 42334;



-- *** FIXES FOR WESTFALL ***


-- Quest #26230 Feast or Famine - fix: Adding the Coyote Tail, the drop rates is from wow head
DELETE FROM `creature_loot_template` WHERE `entry` = 834 AND `item` = 57787;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(834, 57787, -49, 1, 0, 1, 1);


-- Quest #26347 Keeper of the Flame - fix: Adding the Chasm Ooze, the drop rates is from wow head
DELETE FROM `creature_loot_template` WHERE `entry` = 42669 AND `item` = 58204;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(42669, 58204, -89, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 42669 WHERE `entry` = 42669; 


-- Quest #26286 In Defense of Westfall - fix: Adding the Chasm Ooze, the drop rates is from wow head
DELETE FROM `creature_loot_template` WHERE `entry` = 124 AND `item` = 58111;
DELETE FROM `creature_loot_template` WHERE `entry` = 452 AND `item` = 58111;
DELETE FROM `creature_loot_template` WHERE `entry` = 501 AND `item` = 58111;
DELETE FROM `creature_loot_template` WHERE `entry` = 54373 AND `item` = 58111;
DELETE FROM `creature_loot_template` WHERE `entry` = 54372 AND `item` = 58111;
DELETE FROM `creature_loot_template` WHERE `entry` = 54371 AND `item` = 58111;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(124, 58111, -8, 1, 0, 1, 1),
(452, 58111, -7, 1, 0, 1, 1),
(501, 58111, -7, 1, 0, 1, 1),
(54373, 58111, -6, 1, 0, 1, 1),
(54372, 58111, -5, 1, 0, 1, 1),
(54371, 58111, -5, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 54373 WHERE `entry` = 54373; 
UPDATE `creature_template` SET `lootid` = 54372 WHERE `entry` = 54372; 
UPDATE `creature_template` SET `lootid` = 54371 WHERE `entry` = 54371; 


-- Quest #26241 Westfall Stew - fix: Adding the Goretusk Flank, the drop rates is from wow head
DELETE FROM `creature_loot_template` WHERE `entry` = 157 AND `item` = 57788;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(157, 57788, -61, 1, 0, 1, 1);
-- Quest #26241 Westfall Stew - fix: Adding the Stringy Fleshripper Meat, the drop rates is from wow head
DELETE FROM `creature_loot_template` WHERE `entry` = 1109 AND `item` = 57786;
DELETE FROM `creature_loot_template` WHERE `entry` = 199 AND `item` = 57786;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(1109, 57786, -56, 1, 0, 1, 1),
(199, 57786, -55, 1, 0, 1, 1);


-- Fix : Add Flight Master Zaldaan
DELETE FROM creature WHERE guid = 600003;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600003, 43991, 530, 1, 1, 0, 0, -4127.32, -12523.2, 44.232, 2.3876, 300, 0, 0, 18423, 0, 0, 0, 0, 0);


-- Monster Shatterhorn must be changed so players can fight him
UPDATE creature_template SET unit_flags = 0, type_flags = 0 WHERE entry = 24178;


-- Monster Alystros the Verdant Keeper must be changed so players can fight him
UPDATE creature_template SET unit_flags = 0, type_flags = 0 WHERE entry = 27249;



-- *** FIXES FOR THE WETLANDS ***


-- Fix the quest chain for quests 25723, 25725 & 25735 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 25723 WHERE `Id` = 25725;
UPDATE `quest_template` SET `PrevQuestId` = 25725 WHERE `Id` = 25735;


-- Quest #25725 Fenbush Berries - fix: Adding the Handful of Fenberries
DELETE FROM `gameobject_loot_template` WHERE `entry` = 29571 AND `item` = 55233;
INSERT INTO `gameobject_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(29571, 55233, -100, 1, 0, 1, 1);



-- *** FIXES FOR DUN MOROGH ***


-- Fix the quest chain for quests 25997, 25998, 26078, 26085, 26094, 26102 & 26112 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 25997 WHERE `Id` = 25998;
UPDATE `quest_template` SET `PrevQuestId` = 25998 WHERE `Id` = 26078;
UPDATE `quest_template` SET `PrevQuestId` = 26078 WHERE `Id` = 26085;
UPDATE `quest_template` SET `PrevQuestId` = 26085 WHERE `Id` = 26094;
UPDATE `quest_template` SET `PrevQuestId` = 26094 WHERE `Id` = 26102;
UPDATE `quest_template` SET `PrevQuestId` = 26102 WHERE `Id` = 26112;


-- Fix : Add Captain Beld
DELETE FROM creature WHERE guid = 600004;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600004, 6124, 0, 1, 1, 0, 0, -5920.47, -2034.25, 400.749, 3.21401, 300, 0, 0, 297, 0, 0, 0, 0, 0);


-- Fix quest 433: The Public Servant
SET @SPELL := 77819; 
SET @NPC := 41671; 
UPDATE `creature_template` SET `AIName`='SmartAI' WHERE `entry` = @NPC; 
DELETE FROM `smart_scripts` WHERE `entryorguid` = @NPC AND `source_type`=0; 
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, 
`event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, 
`action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
(@NPC,0,0,1,8,0,100,0x01,@SPELL,0,0,0,33,@NPC,0,0,0,0,0,7,0,0,0,0,0,0,0, 'Trapped Miner - On spell hit - Give kill credit for quest 433'), 
(@NPC,0,1,0,61,0,100,1,0,0,0,0,41,1000,0,0,0,0,0,1,0,0,0,0,0,0,0, 'Trapped Miner - Despawn after 1 seconds'); 



-- *** FIXES FOR LOCH MODAN ***


-- Fix the quest chain for quests 26845, 26864, 26927, 26928 & 26868 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26845 WHERE `Id` = 26864;
UPDATE `quest_template` SET `PrevQuestId` = 26864 WHERE `Id` = 26927;
UPDATE `quest_template` SET `PrevQuestId` = 26927 WHERE `Id` = 26928;
UPDATE `quest_template` SET `PrevQuestId` = 26928 WHERE `Id` = 26868;


-- Fix the quest chain for quests 13636, 26843 & 26844 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 13636 WHERE `Id` = 26843;
UPDATE `quest_template` SET `PrevQuestId` = 26843 WHERE `Id` = 26844;



-- *** FIXES FOR ELWYNN FOREST ***


-- Fix the quest chain for quests 26393, 26394, 26395 & 26396 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26393 WHERE `Id` = 26394;
UPDATE `quest_template` SET `PrevQuestId` = 26394 WHERE `Id` = 26395;
UPDATE `quest_template` SET `PrevQuestId` = 26395 WHERE `Id` = 26396;


-- Fix the quest chain for quests 26688, 26689, 26690 & 26691 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26688 WHERE `Id` = 26689;
UPDATE `quest_template` SET `PrevQuestId` = 26689 WHERE `Id` = 26690;
UPDATE `quest_template` SET `PrevQuestId` = 26690 WHERE `Id` = 26691;



-- *** FIXES FOR DUSKWOOD ***


-- Fix the quest chain for quests 26653, 26652, 26654, 26655, 26660, 26661, 26676, 26680, 26677, 26681 & 26727 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26653 WHERE `Id` = 26652;
UPDATE `quest_template` SET `PrevQuestId` = 26652 WHERE `Id` = 26654;
UPDATE `quest_template` SET `PrevQuestId` = 26654 WHERE `Id` = 26655;
UPDATE `quest_template` SET `PrevQuestId` = 26655 WHERE `Id` = 26660;
UPDATE `quest_template` SET `PrevQuestId` = 26660 WHERE `Id` = 26661;
UPDATE `quest_template` SET `PrevQuestId` = 26661 WHERE `Id` = 26676;
UPDATE `quest_template` SET `PrevQuestId` = 26676 WHERE `Id` = 26680;
UPDATE `quest_template` SET `PrevQuestId` = 26680 WHERE `Id` = 26677;
UPDATE `quest_template` SET `PrevQuestId` = 26677 WHERE `Id` = 26681;
UPDATE `quest_template` SET `PrevQuestId` = 26681 WHERE `Id` = 26727;


-- Fix the quest chain for quests 26683, 26684 & 26685 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26683 WHERE `Id` = 26684;
UPDATE `quest_template` SET `PrevQuestId` = 26684 WHERE `Id` = 26685;


-- Fix the quest chain for quests 26666, 26667, 26669. 26670, 26671, 26672 & 26674 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26666 WHERE `Id` = 26667;
UPDATE `quest_template` SET `PrevQuestId` = 26667 WHERE `Id` = 26669;
UPDATE `quest_template` SET `PrevQuestId` = 26669 WHERE `Id` = 26670;
UPDATE `quest_template` SET `PrevQuestId` = 26670 WHERE `Id` = 26671;
UPDATE `quest_template` SET `PrevQuestId` = 26671 WHERE `Id` = 26672;
UPDATE `quest_template` SET `PrevQuestId` = 26672 WHERE `Id` = 26674;



-- *** FIXES FOR WETLANDS ***


-- NO UPLOAD - Fix the quest chain for quests 26137, 25395, 25770, 25721, 25727, 25733, 25777 & 25780 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26137 WHERE `Id` = 25395;
UPDATE `quest_template` SET `PrevQuestId` = 25395 WHERE `Id` = 25770;
UPDATE `quest_template` SET `PrevQuestId` = 25770 WHERE `Id` = 25721;
UPDATE `quest_template` SET `PrevQuestId` = 25721 WHERE `Id` = 25727;
UPDATE `quest_template` SET `PrevQuestId` = 25727 WHERE `Id` = 25733;
UPDATE `quest_template` SET `PrevQuestId` = 25733 WHERE `Id` = 25777;
UPDATE `quest_template` SET `PrevQuestId` = 25777 WHERE `Id` = 25780;


-- Fix the quest chain for quests 25722, 25726 & 25734 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 25722 WHERE `Id` = 25726;
UPDATE `quest_template` SET `PrevQuestId` = 25726 WHERE `Id` = 25734;


-- Fix the quest chain for quests 25802, 25803, 25804 & 25805 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 25802 WHERE `Id` = 25803;
UPDATE `quest_template` SET `PrevQuestId` = 25803 WHERE `Id` = 25804;
UPDATE `quest_template` SET `PrevQuestId` = 25804 WHERE `Id` = 25805;


-- Fix the quest chain for quests 26980, 25864 & 25865 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26980 WHERE `Id` = 25864;
UPDATE `quest_template` SET `PrevQuestId` = 25864 WHERE `Id` = 25865;


-- Correct the Half-Buried Barrel, the Damaged Crate and the Sealed Barrel 
-- so they can be selectable and they can give their quests.  Previous flags entry was 4
UPDATE gameobject_template SET flags = 0 WHERE entry = 261;
UPDATE gameobject_template SET flags = 0 WHERE entry = 142151;
UPDATE gameobject_template SET flags = 0 WHERE entry = 259;


-- Quest #25865 The Mosshide Job - fix: Adding the Ironforge Ingot
DELETE FROM `creature_loot_template` WHERE `entry` = 41390 AND `item` = 56088;
DELETE FROM `creature_loot_template` WHERE `entry` = 41391 AND `item` = 56088;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(41390, 56088, -75, 1, 0, 1, 1),
(41391, 56088, -75, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 41390 WHERE `entry` = 41390; 
UPDATE `creature_template` SET `lootid` = 41391 WHERE `entry` = 41391; 


-- NO UPLOAD - Fix the quest chain for quests 25866, 25867 & 25868 so they follow the chain correctly
UPDATE `quest_template` SET `NextQuestIDChain` = 25867 WHERE `Id` = 25866;
UPDATE `quest_template` SET `NextQuestIDChain` = 25868 WHERE `Id` = 25867;
UPDATE `quest_template` SET `PrevQuestId` = 25866 WHERE `Id` = 25867;
UPDATE `quest_template` SET `PrevQuestId` = 25867 WHERE `Id` = 25868;


-- Quest #25867 Gnoll Escape - fix: Adding the Trapper's Key
DELETE FROM `creature_loot_template` WHERE `entry` = 41409 AND `item` = 56081;
DELETE FROM `creature_loot_template` WHERE `entry` = 44225 AND `item` = 56081;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(41409, 56081, -100, 1, 0, 1, 1),
(44225, 56081, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 41409 WHERE `entry` = 41409; 
UPDATE `creature_template` SET `lootid` = 44225 WHERE `entry` = 44225; 


-- NO UPLOAD Quest #25865 Gnoll Escape - Autocomplete
update quest_template set flags = 65536 WHERE id = 25867;


-- Fix the quest chain for quests 25856 & 25857 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 25856 WHERE `Id` = 25857;


-- Fix the quest chain for quests 25854 & 25855 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 25854 WHERE `Id` = 25855;


-- Fix the quest chain for quests 25939 & 26196 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 25939 WHERE `Id` = 26196;


-- Quest #25856 Crocolisk Hides - fix: Adding the Marshy Crocolisk Hide
DELETE FROM `creature_loot_template` WHERE `entry` = 41419 AND `item` = 56087;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(41419, 56087, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 41419 WHERE `entry` = 41419; 


-- Quest #25857 Hunting Horrorjaw - fix: Adding the Horrorjaw's Hide
DELETE FROM `creature_loot_template` WHERE `entry` = 41420 AND `item` = 56089;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(41420, 56089, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 41420 WHERE `entry` = 41420; 


-- Fix the quest chain for quests 25926 & 25927 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 25926 WHERE `Id` = 25927;


-- Fix the quest chain for quests 26327, 26127, 26128 & 26139 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26327 WHERE `Id` = 26127;
UPDATE `quest_template` SET `PrevQuestId` = 26127 WHERE `Id` = 26128;
UPDATE `quest_template` SET `PrevQuestId` = 26128 WHERE `Id` = 26139;


-- Fix the quest chain for quests 13639, 309 & 13650 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 13639 WHERE `Id` = 309;
UPDATE `quest_template` SET `PrevQuestId` = 309 WHERE `Id` = 13650;


-- NO UPLOAD Quest #13650 Keep Your Hands Off The Goods! - Autocomplete
update quest_template set flags = 65536 WHERE id = 13650;


-- NO UPLOAD Quest #25939 For Peat's Sake - Autocomplete
update quest_template set flags = 65536 WHERE id = 25939;


-- NO UPLOAD Quest #26531  - Autocomplete
update quest_template set flags = 65536 WHERE id = 26868;


-- NO UPLOAD Quest #26531 Summoning Shadra - Autocomplete
update quest_template set flags = 134217736, method = 2, RequiredNpcOrGo1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGo3 = 0, 
RequiredNpcOrGoCount1 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGoCount3 = 0, RequiredSourceItemId4 = 0, 
RequiredSourceItemCount4 = 0 WHERE id = 26531;
update quest_template set flags = 134217736, method = 2, RequiredNpcOrGo1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGo3 = 0, 
RequiredNpcOrGoCount1 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGoCount3 = 0, RequiredSourceItemId4 = 0, 
RequiredSourceItemCount4 = 0 WHERE id = 26532;


-- ARATI + LOCH + WETLANDS


-- Fix the quest chain for quests 26981, 25849, 26189 & 26195 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26981 WHERE `Id` = 25849;
UPDATE `quest_template` SET `PrevQuestId` = 25849 WHERE `Id` = 26189;
UPDATE `quest_template` SET `PrevQuestId` = 26189 WHERE `Id` = 26195;

-- Fix the quest chain for quests 26035, 26036, 26037 & 26038 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26035 WHERE `Id` = 26036;
UPDATE `quest_template` SET `PrevQuestId` = 26036 WHERE `Id` = 26037;
UPDATE `quest_template` SET `PrevQuestId` = 26037 WHERE `Id` = 26038;

-- Fix the quest chain for quests 26113, 26110 & 26114 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26113 WHERE `Id` = 26110;
UPDATE `quest_template` SET `PrevQuestId` = 26110 WHERE `Id` = 26114;

-- Fix the quest chain for quests 26528, 26529, 26530, 26531 & 26532 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26528 WHERE `Id` = 26529;
UPDATE `quest_template` SET `PrevQuestId` = 26529 WHERE `Id` = 26530;
UPDATE `quest_template` SET `PrevQuestId` = 26530 WHERE `Id` = 26531;
UPDATE `quest_template` SET `PrevQuestId` = 26531 WHERE `Id` = 26532;

-- Fix the quest chain for quests 26641 & 26643 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26641 WHERE `Id` = 26643;

-- Quest #26528 The Eye of Shadra - fix: Adding the Eye of Shadra
DELETE FROM `gameobject_loot_template` WHERE `entry` = 30439 AND `item` = 58282;
INSERT INTO `gameobject_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(30439, 58282, -100, 1, 0, 1, 1);

-- Quest #26530 The Shell of Shadra - fix: Adding the Shell of Shadra
DELETE FROM `creature_loot_template` WHERE `entry` = 42919 AND `item` = 58779;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(42919, 58779, -100, 1, 0, 1, 1);
UPDATE `creature_template` SET `lootid` = 42919 WHERE `entry` = 42919; 



-- NEW FIXES 2013-02-18


-- Fix the quest chain for quests 27775 & 27775 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 27775 WHERE `Id` = 27776;


-- Fix the quest chain for quests 27823 & 27824 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 27823 WHERE `Id` = 27824;


-- Fix the quest chain for quests 26961 & 13647 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26961 WHERE `Id` = 13647;


-- Fix the quest chain for quests 27031, 27032, 27033, 27034, 27035 & 27074 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 27031 WHERE `Id` = 27032;
UPDATE `quest_template` SET `PrevQuestId` = 27032 WHERE `Id` = 27033;
UPDATE `quest_template` SET `PrevQuestId` = 27033 WHERE `Id` = 27034;
UPDATE `quest_template` SET `PrevQuestId` = 27034 WHERE `Id` = 27035;
UPDATE `quest_template` SET `PrevQuestId` = 27035 WHERE `Id` = 27074;


-- Fix the quest chain for quests 27036 & 27037 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 27036 WHERE `Id` = 27037;


-- Fix the quest chain for quests 27025 & 27026 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 27025 WHERE `Id` = 27026;


-- Fix the quest chain for quests 25841 & 25882 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 25841 WHERE `Id` = 25882;


-- Fix the quest chain for quests 27078, 27115 & 27116 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 27078 WHERE `Id` = 27115;
UPDATE `quest_template` SET `PrevQuestId` = 27115 WHERE `Id` = 27116;


-- Quest #27823 A Dwarf's Got Needs - fix: Adding the Shadowstout
DELETE FROM `creature_loot_template` WHERE `entry` IN (2739, 2740) AND `item` = 62510;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(2739, 62510, -90, 1, 0, 1, 2),
(2740, 62510, -90, 1, 0, 1, 2);


-- NO UPLOAD Zul Drak fix object
UPDATE gameobject_template SET flags = 0 WHERE entry = 190535;
UPDATE gameobject_template SET flags = 0 WHERE entry = 187565;


-- NO UPLOAD - It's Raid Night Every Night - Autocomplete
update quest_template set flags = 65536 WHERE id = 25932;

-- NO UPLOAD - Rams on the Lam - Autocomplete
update quest_template set flags = 65536 WHERE id = 25905;

-- NO UPLOAD - Entombed in Ice - Autocomplete
update quest_template set flags = 65536 WHERE id = 25978;

-- NO UPLOAD - Strike from Above - Autocomplete
update quest_template set flags = 65536 WHERE id = 25841;


-- Fix quest 28868: The View from Down Here
SET @SPELL := 93773; 
SET @NPC := 41251; 
SET @NPC_REWARD := 50606; 
UPDATE `creature_template` SET `AIName`='SmartAI' WHERE `entry` = @NPC; 
DELETE FROM `smart_scripts` WHERE `entryorguid` = @NPC AND `source_type`=0; 
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, 
`event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, 
`action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
(@NPC,0,0,1,8,0,100,0x01,@SPELL,0,0,0,33,@NPC_REWARD,0,0,0,0,0,7,0,0,0,0,0,0,0, 'Frostmane Builder - On spell hit - Give kill credit for quest 28868'), 
(@NPC,0,1,0,61,0,100,1,0,0,0,0,41,3000,0,0,0,0,0,1,0,0,0,0,0,0,0, 'Frostmane Builder - Despawn after 3 seconds'); 


-- Fix quest 25867: Gnoll Escape
SET @NPC := 41438; 
SET @GAMEOBJ := 203282;
UPDATE `gameobject_template` SET `AIName`='SmartGameObjectAI' WHERE `entry` = @GAMEOBJ; 
DELETE FROM `smart_scripts` WHERE `entryorguid` = @GAMEOBJ AND `source_type`=1; 
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, 
`event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, 
`action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
(@GAMEOBJ,1,0,0,70,0,100,0,2,0,0,0,33,@NPC,0,0,0,0,0,7,0,0,0,0,0,0,0,'Gnoll Cage - On activate - Give credit for quest 25867');


-- Fix : Add Magistrix Nizara
DELETE FROM creature WHERE guid = 600005;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600005, 50484, 530, 1, 1, 0, 0, 9348.69, -7171.92, 13.559, 3.13816, 300, 0, 0, 3052, 0, 0, 0, 0, 0);



-- FIXES FOR 2013-02-20


-- Fix the quest chain for quests 24469 & 24470 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 24469 WHERE `Id` = 24470;


-- Fix the quest chain for quests 24474 & 24475 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 24474 WHERE `Id` = 24475;


-- Fix the quest chain for quests 24487 & 182 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 24487 WHERE `Id` = 182;


-- Fix the quest chain for quests 24477 & 24486 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 24477 WHERE `Id` = 24486;


-- Fix the quest chain for quests 218 & 24490 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 218 WHERE `Id` = 24490;


-- Fix the quest chain for quests 24491 & 24492 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 24491 WHERE `Id` = 24492;


-- NO UPLOAD - Trolling for information - Autocomplete
update quest_template set flags = 65536 WHERE id = 24489;


-- Fix : Add Milo Geartwinge
DELETE FROM creature WHERE guid = 600006;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600006, 37113, 0, 1, 1, 0, 0, -6246.15, 305.387, 383.81, 3.02356, 300, 0, 0, 42, 0, 0, 0, 0, 0);


-- FIXES FOR 2013-02-22


-- Old gossip menu was 900
UPDATE creature_template SET gossip_menu_id = 0 WHERE name = 'Alchemist Pestlezugg';

-- OLD VALUE : 11777
UPDATE creature_template SET gossip_menu_id = 0 WHERE name = 'Brolan Galebeard';

-- OLD VALUE : 7470
UPDATE creature_template SET gossip_menu_id = 0 WHERE name = 'Laando';

-- OLD VALUE : 12032
UPDATE creature_template SET gossip_menu_id = 0 WHERE name = 'Janice Myers';

-- Fix quest 25792: Pushing Forward
SET @SPELL := 77314; 
SET @NPC := 41202; 
SET @NPC_REWARD := 41202; 
UPDATE `creature_template` SET `AIName`='SmartAI' WHERE `entry` = @NPC; 
DELETE FROM `smart_scripts` WHERE `entryorguid` = @NPC AND `source_type`=0; 
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, 
`event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, 
`action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
(@NPC,0,0,1,8,0,100,0x01,@SPELL,0,0,0,33,@NPC_REWARD,0,0,0,0,0,7,0,0,0,0,0,0,0, 'Constriction Totem - On spell hit - Give kill credit for quest 25792'), 
(@NPC,0,1,0,61,0,100,1,0,0,0,0,41,1000,0,0,0,0,0,1,0,0,0,0,0,0,0, 'Constriction Totem - Despawn after 1 second'); 


-- Fix : Add Hogger
DELETE FROM creature WHERE guid = 600007;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600007, 46254, 34, 1, 1, 0, 0, 156.204, 106.446, -35.1895, 2.65891, 300, 0, 0, 23456, 0, 0, 0, 0, 0);


-- Fix quest 14108: Get Kraken!
SET @SPELL := 66588; 
SET @NPC := 34925; 
SET @NPC_REWARD := 35009; 
UPDATE `creature_template` SET `AIName`='SmartAI' WHERE `entry` = @NPC; 
DELETE FROM `smart_scripts` WHERE `entryorguid` = @NPC AND `source_type`=0; 
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, 
`event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, 
`action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
(@NPC,0,0,1,8,0,100,0x01,@SPELL,0,0,0,33,@NPC_REWARD,0,0,0,0,0,7,0,0,0,0,0,0,0, 'North Sea Kraken - On spell hit - Give kill credit for quest 14108'),
(@NPC,0,1,0,61,0,100,1,0,0,0,0,41,1000,0,0,0,0,0,1,0,0,0,0,0,0,0, 'North Sea Kraken - Despawn after 1 second'); 
UPDATE creature SET spawntimesecs = 20 WHERE id = 34925;


-- Fix : Argent Tournament
DELETE FROM creature WHERE guid = 600008;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES (
600008, 34965, 571, 1, 1, 0, 0, 10180.1, 1182.51, 76.2133, 6.13811, 300, 0, 0, 10080, 8814, 0, 0, 0, 0);


-- Previous Value was 768
UPDATE creature_template SET unit_flags = 0 where entry = 41202;

-- NO UPLOAD - Kharanos Report - Autocomplete
update quest_template set flags = 65536 WHERE id = 313;

-- NO UPLOAD - The Fight Continues - Autocomplete
update quest_template set flags = 65536 WHERE id = 26208;

-- NO UPLOAD - A Job for the multi bot - Autocomplete
update quest_template set flags = 65536 WHERE id = 26205;

-- NO UPLOAD - 26364 - Down with Crushcog! - Autocomplete
update quest_template set flags = 65536 WHERE id = 26364;

-- NO UPLOAD - 28002 - Crisis Management - Autocomplete
update quest_template set flags = 65536 WHERE id = 28002;

-- NO UPLOAD - 27926 - Eastern Hospitality - Autocomplete
update quest_template set flags = 65536 WHERE id = 27926;

-- NO UPLOAD - 28134 - Impending Retribution - Autocomplete
update quest_template set flags = 65536 WHERE id = 28134;


-- NO UPLOAD - Missing in action is out
UPDATE `quest_template` SET `PrevQuestId` = 26285 WHERE `Id` = 26318;
update quest_template set Level = 90, MinLevel = 90 WHERE id = 26284;

-- NO UPLOAD - Quest 26318 - Finishin' the job
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0 WHERE id = 26318;

-- NO UPLOAD - Decontamination - Autocomplete
update quest_template set flags = 134217736, Level = 90, MinLevel = 90, method = 0, RequiredNpcOrGo1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGo3 = 0, 
RequiredNpcOrGoCount1 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGoCount3 = 0, RequiredSourceItemId4 = 0, 
RequiredSourceItemCount4 = 0 WHERE id = 27635;


-- FIXES FOR 2013-03-02


-- Fix quest 27671: See to the Survivors
SET @SPELL := 86264; 
SET @NPC := 46268; 
SET @NPC_REWARD := 46268; 
UPDATE `creature_template` SET `AIName`='SmartAI' WHERE `entry` = @NPC; 
DELETE FROM `smart_scripts` WHERE `entryorguid` = @NPC AND `source_type`=0; 
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, 
`event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, 
`action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
(@NPC,0,0,1,8,0,100,0x01,@SPELL,0,0,0,33,@NPC_REWARD,0,0,0,0,0,7,0,0,0,0,0,0,0, 'Survivor - On spell hit - Give kill credit for quest 27671'),
(@NPC,0,1,0,61,0,100,1,0,0,0,0,41,2000,0,0,0,0,0,1,0,0,0,0,0,0,0, 'Survivor - Despawn after 2 seconds'); 


-- Fix quest 14077: The Light's Mercy
SET @SPELL := 66390; 
SET @NPC := 34852; 
SET @NPC_REWARD := 34852; 
UPDATE `creature_template` SET `AIName`='SmartAI' WHERE `entry` = @NPC; 
DELETE FROM `smart_scripts` WHERE `entryorguid` = @NPC AND `source_type`=0; 
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, 
`event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, 
`action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
(@NPC,0,0,1,8,0,100,0x01,@SPELL,0,0,0,33,@NPC_REWARD,0,0,0,0,0,7,0,0,0,0,0,0,0, 'Slain Tualiq Villager - On spell hit - Give kill credit for quest 14077'),
(@NPC,0,1,0,61,0,100,1,0,0,0,0,41,2000,0,0,0,0,0,1,0,0,0,0,0,0,0, 'Slain Tualiq Villager - Despawn after 2 seconds'); 


-- Fix quest 14107: The Fate Of The Fallen
SET @SPELL := 66719; 
SET @NPC := 32149; 
SET @NPC_REWARD := 35055; 
UPDATE `creature_template` SET `AIName`='SmartAI' WHERE `entry` = @NPC; 
DELETE FROM `smart_scripts` WHERE `entryorguid` = @NPC AND `source_type`=0; 
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, 
`event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, 
`action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
(@NPC,0,0,1,8,0,100,0x01,@SPELL,0,0,0,33,@NPC_REWARD,0,0,0,0,0,7,0,0,0,0,0,0,0, 'Fallen Hero''s Spirit - On spell hit - Give kill credit for quest 14107'), 
(@NPC,0,1,0,61,0,100,1,0,0,0,0,41,2000,0,0,0,0,0,1,0,0,0,0,0,0,0, 'Fallen Hero''s Spirit - Despawn after 2 second'); 


-- Fix the quest chain for quests 26208, 26566, 26222 & 26205 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26208 WHERE `Id` = 26566;
UPDATE `quest_template` SET `PrevQuestId` = 26566 WHERE `Id` = 26222;
UPDATE `quest_template` SET `PrevQuestId` = 26222 WHERE `Id` = 26205;


-- Fix the quest chain for quests 26318, 26329 & 26331 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26318 WHERE `Id` = 26329;
UPDATE `quest_template` SET `PrevQuestId` = 26329 WHERE `Id` = 26331;


-- Fix the quest chain for quests 26339, 26342 & 26364 so they follow the chain correctly
UPDATE `quest_template` SET `PrevQuestId` = 26339 WHERE `Id` = 26342;
UPDATE `quest_template` SET `PrevQuestId` = 26342 WHERE `Id` = 26364;


-- Fix quest 26333: No Tanks!
SET @SPELL := 79751; 
SET @NPC := 42224; 
SET @NPC_REWARD := 42224; 
UPDATE `creature_template` SET `AIName`='SmartAI' WHERE `entry` = @NPC; 
DELETE FROM `smart_scripts` WHERE `entryorguid` = @NPC AND `source_type`=0; 
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, 
`event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, 
`action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
(@NPC,0,0,1,8,0,100,0x01,@SPELL,0,0,0,33,@NPC_REWARD,0,0,0,0,0,7,0,0,0,0,0,0,0, 'Repaired Mechano-Tank - On spell hit - Give kill credit for quest 26333'), 
(@NPC,0,1,0,61,0,100,1,0,0,0,0,41,1000,0,0,0,0,0,1,0,0,0,0,0,0,0, 'Repaired Mechano-Tank - Despawn after 1 second'); 

-- Fix quest 26342: Paint It Black
SET @SPELL := 79781; 
SET @NPC := 42291; 
SET @NPC_REWARD := 42796; 
UPDATE `creature_template` SET `AIName`='SmartAI' WHERE `entry` = @NPC; 
DELETE FROM `smart_scripts` WHERE `entryorguid` = @NPC AND `source_type`=0; 
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, 
`event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, 
`action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
(@NPC,0,0,0,8,0,100,0x01,@SPELL,0,0,0,33,@NPC_REWARD,0,0,0,0,0,7,0,0,0,0,0,0,0, 'Crushcog Sentry-Bot - On spell hit - Give kill credit for quest 26342');

-- NO UPLOAD Quest 309 - Protecting the shipment - Hide the quest
update quest_template set minlevel = 12, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, flags = 8 WHERE id = 309;
DELETE FROM creature_involvedrelation WHERE id = 1344 AND quest = 309;
DELETE FROM creature_questrelation WHERE id = 2057 AND quest = 309;
INSERT INTO creature_involvedrelation (id, quest) VALUES (1344, 309);

-- *** Arathi Highlands ***

-- Calamoth Ashbeard, needs to be hostile and quest needs to be corrected
UPDATE creature_template SET faction_A = 834, faction_H = 834, gossip_menu_id = 0, npcflag = 0, unit_flags = 0, unit_flags2 = 0, dynamicflags = 0, type = 6, type_flags = 0, lootid = 0, VehicleId = 0, minlevel = 25, maxlevel = 25 WHERE entry = 41522;
UPDATE quest_template SET RequiredNpcOrGo1 = 41522, RequiredNpcOrGoCount1 = 1, flags = 8 WHERE id = 26128;

-- spawn the creature to kill: Calamoth Ashbeard
DELETE FROM creature WHERE guid = 600100;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES 
(600100, 41522, 0, 1, 1, 0, 0, -2406.29, -2502.62, 85.2471, 3.16075, 300, 0, 0, 1633, 0, 0, 0, 0, 0);

-- Correct the game objects so they can start / end quests.  Previous flags entry was 4
UPDATE gameobject_template SET flags = 0 WHERE entry = 138492;
UPDATE gameobject_template SET flags = 0 WHERE entry = 2701;
UPDATE gameobject_template SET flags = 0 WHERE entry = 2702;
UPDATE gameobject_template SET flags = 0 WHERE entry = 2688;
UPDATE gameobject_template SET flags = 0 WHERE flags = 4 AND entry = 2713;
UPDATE gameobject_template SET flags = 0 WHERE flags = 4 AND entry = 156561;
UPDATE gameobject_template SET flags = 0 WHERE flags = 4 AND entry = 203734;

-- Quest 26049 The Princess Unleashed, spawn the princess
DELETE FROM creature WHERE guid = 600101;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES 
(600101, 2755, 0, 1, 1, 0, 0, -918.028, -3085.14, 49.5206, 4.05761, 300, 0, 0, 4278, 4449, 0, 0, 0, 0);

-- Farmer Fulbrow and investigator and westfall, Remove Aura so the NPCs are shown
UPDATE creature_template_addon SET auras = '' WHERE entry = 237;
UPDATE creature_template_addon SET auras = '' WHERE entry = 42308;

-- Fix Griphon Master Gyll so you can catch a ride
UPDATE creature_template SET gossip_menu_id = 0 WHERE name = 'Gyll';

-- *** FIXES FOR THE HINTERLANDS ***

-- Fix Deathstalker invader so they are hostile with the correct level
UPDATE creature_template SET minlevel = 34, maxlevel = 34, faction_A = 14, faction_H = 14 WHERE entry = 43541;

-- Spawn the missing mobs in the hinterlands
DELETE FROM creature WHERE guid >= 600102 AND guid <= 600116;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES 
(600102, 42877, 0, 1, 1, 0, 0, -761.733, -3792.48, 233.808, 0.529536, 300, 0, 0, 1856, 963, 0, 0, 0, 0),
(600103, 43541, 0, 1, 1, 0, 0, 310.838, -2875.65, 114.012, 1.51989, 300, 0, 0, 1163, 0, 0, 0, 0, 0),
(600104, 43541, 0, 1, 1, 0, 0, 350.967, -2869.36, 116.369, 2.15605, 300, 0, 0, 1163, 0, 0, 0, 0, 0),
(600105, 43541, 0, 1, 1, 0, 0, 315.207, -2826.22, 118.527, 4.89709, 300, 0, 0, 1163, 0, 0, 0, 0, 0),
(600106, 43541, 0, 1, 1, 0, 0, 271.373, -2832.83, 113.39, 3.32237, 300, 0, 0, 1163, 0, 0, 0, 0, 0),
(600107, 43541, 0, 1, 1, 0, 0, 260.59, -2867.65, 112.466, 4.74787, 300, 0, 0, 1163, 0, 0, 0, 0, 0),
(600108, 43541, 0, 1, 1, 0, 0, 203.365, -2888.53, 104.737, 3.92713, 300, 0, 0, 1163, 0, 0, 0, 0, 0),
(600109, 43541, 0, 1, 1, 0, 0, 188.762, -2836.73, 107.796, 1.67696, 300, 0, 0, 1163, 0, 0, 0, 0, 0),
(600110, 43541, 0, 1, 1, 0, 0, 184.941, -2772.89, 112.761, 0.561695, 300, 0, 0, 1163, 0, 0, 0, 0, 0),
(600111, 43541, 0, 1, 1, 0, 0, 208.201, -2699.09, 114.982, 0.306441, 300, 0, 0, 1163, 0, 0, 0, 0, 0),
(600112, 43541, 0, 1, 1, 0, 0, 232.921, -2718.45, 115.608, 4.54367, 300, 0, 0, 1163, 0, 0, 0, 0, 0),
(600113, 43541, 0, 1, 1, 0, 0, 213.378, -2737.37, 123.371, 5.35655, 300, 0, 0, 1163, 0, 0, 0, 0, 0),
(600114, 43541, 0, 1, 1, 0, 0, 260.68, -2804.7, 123.369, 2.18747, 300, 0, 0, 1163, 0, 0, 0, 0, 0),
(600115, 43541, 0, 1, 1, 0, 0, 352.812, -2789.69, 120.521, 4.04886, 300, 0, 0, 1163, 0, 0, 0, 0, 0),
(600116, 43541, 0, 1, 1, 0, 0, 377.425, -2870.29, 124, 2.48592, 300, 0, 0, 1163, 0, 0, 0, 0, 0);

-- Quest #27626 fix : The Highvale Documents.  Add the quest loot
DELETE FROM `creature_loot_template` WHERE `entry` = 43541 AND `item` = 61972;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES (43541, 61972, -33, 1, 0, 1, 1);
DELETE FROM `creature_loot_template` WHERE `entry` = 43541 AND `item` = 61973;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES (43541, 61973, -33, 1, 0, 1, 1);
DELETE FROM `creature_loot_template` WHERE `entry` = 43541 AND `item` = 61974;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES (43541, 61974, -33, 1, 0, 1, 1);

-- Quest #26485 fix : Snapjaws, Lad!  Add the Snapjaw Gizzard loot.
DELETE FROM `creature_loot_template` WHERE `entry` = 2505 AND `item` = 58867;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(2505, 58867, -75, 1, 0, 1, 1);

-- Quest #26517 fix : Summit of Fate.  Add the Spider Idol loot.
DELETE FROM `creature_loot_template` WHERE `entry` = 42879 AND `item` = 58228;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(42879, 58228, -100, 1, 0, 1, 1);

-- Quest #26517 fix : Skittering Spiderling.  Add the Skittering Spiderling loot.
UPDATE `creature_template` SET `lootid` = 42689 WHERE `entry` = 42689; 
DELETE FROM `creature_loot_template` WHERE `entry` = 42689 AND `item` = 58120;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(42689, 58120, -100, 1, 0, 1, 1);

-- Quest #26521 - Faces of Evil.  Autocomplete
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0 WHERE id = 26521;

-- Quest #26546 - Razorbeak friends, do not allow the player to do this quest so the other one in the multi select must be picked
update quest_template set Level = 90, MinLevel = 90 WHERE id = 26546;

-- Class quest cannot be done so we hide them
update quest_template set Level = 90, MinLevel = 90 WHERE Title = 'Steady Shot';
update quest_template set Level = 90, MinLevel = 90 WHERE Title = 'Charge';

-- This quest doesn't work at all and leads to other bugged quests so we hide it
update quest_template set Level = 90, MinLevel = 90 WHERE Title = 'The Ultrasafe Personnel Launcher';
DELETE FROM creature_questrelation WHERE quest = 25839;


-- *** FIXES FOR DUSTWALLOW MARSH START ***

-- Spawn the missing NPCs and mobs
DELETE FROM creature WHERE guid >= 600900 and guid <= 600999;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES 
(600900, 23569, 1, 1, 1, 0, 0, -2624.62, -4324.21, -4.12782, 2.13231, 120, 0, 0, 1093, 1142, 0, 0, 0, 0),
(600901, 23864, 1, 1, 1, 0, 0, -2949.91, -3838.37, 31.6737, 5.4217, 120, 0, 0, 2100, 1097, 0, 0, 0, 0),
(600902, 23786, 1, 1, 1, 0, 0, -4322.74, -3318.35, 34.2538, 3.56029, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600903, 23786, 1, 1, 1, 0, 0, -4318.54, -3283.16, 35.2718, 4.12578, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600904, 23786, 1, 1, 1, 0, 0, -4345.25, -3346.99, 35.0398, 2.11517, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600905, 23786, 1, 1, 1, 0, 0, -4365.17, -3339.13, 34.6981, 6.1207, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600906, 23786, 1, 1, 1, 0, 0, -4371.41, -3323.9, 34.423, 0.677881, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600907, 23786, 1, 1, 1, 0, 0, -4350.28, -3298.56, 34.4633, 5.20178, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600908, 23786, 1, 1, 1, 0, 0, -4320.83, -3334.2, 34.858, 1.83241, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600909, 23786, 1, 1, 1, 0, 0, -4351.73, -3275.65, 46.0588, 6.27777, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600910, 23786, 1, 1, 1, 0, 0, -4377.52, -3258.85, 36.8154, 5.56698, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600911, 23786, 1, 1, 1, 0, 0, -4322.74, -3235.25, 34.3069, 4.88761, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600912, 23786, 1, 1, 1, 0, 0, -4296.48, -3265.25, 39.2565, 5.28816, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600913, 23786, 1, 1, 1, 0, 0, -4268.19, -3291.33, 36.0869, 3.49745, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600914, 23786, 1, 1, 1, 0, 0, -4265.67, -3353.87, 35.5403, 5.76725, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600915, 23786, 1, 1, 1, 0, 0, -4309.62, -3379.01, 35.741, 3.32467, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600916, 23786, 1, 1, 1, 0, 0, -4345.55, -3398.22, 41.3398, 0.760337, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600917, 23786, 1, 1, 1, 0, 0, -4381.86, -3397.67, 40.4038, 2.81415, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600918, 23786, 1, 1, 1, 0, 0, -4385.25, -3379.14, 35.0424, 3.76056, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600919, 23786, 1, 1, 1, 0, 0, -4403.99, -3285.61, 34.1143, 5.02112, 120, 0, 0, 1829, 0, 0, 0, 0, 0),
(600920, 23789, 1, 1, 1, 0, 0, -4695.37, -3718.68, 49.8744, 0.630793, 120, 0, 0, 2536, 1332, 0, 0, 0, 0),
(600921, 39946, 1, 1, 1, 0, 0, -4459.39, -538.637, 6.28171, 6.12464, 120, 0, 0, 2769, 0, 0, 0, 0, 0), -- Missing NPC in Feralas
(600922, 23941, 1, 1, 1, 0, 0, -4030.23, -4979.88, 7.78167, 5.35889, 120, 0, 0, 2100, 1097, 0, 0, 0, 0), -- Gavis Greyshield
(600923, 23928, 1, 1, 1, 0, 0, -4244.28, -3940.02, -12.1534, 5.64557, 120, 0, 0, 1336, 0, 0, 0, 0, 0); -- Lurking Shark

-- spawn some the tool kit and Secondhand Diving Gear game objects
DELETE FROM gameobject WHERE guid >= 600985 AND guid <= 600986;
INSERT INTO gameobject (guid, id, map, spawnMask, phaseMask, position_x, position_y, position_z, orientation, rotation0, rotation1, rotation2, rotation3, spawntimesecs, animprogress, state) VALUES 
(600985, 186273, 1, 1, 1, -2668.82, -4213.75, 0.534, 0, 0, 0, 0, 1, 120, 0, 1),
(600986, 186272, 1, 1, 1, -2679.64, -4279.25, 3.622, 0, 0, 0, 0, 1, 120, 0, 1);

-- Quest #27237 Recover the Cargo! - Autocomplete
update quest_template set SpecialFlags = 0, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id = 27237;

-- Quest #27239 Survey Alcaz Island - Autocomplete
update quest_template set Flags = 65536, SpecialFlags = 0, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id = 27239;

-- Update the flag so the loose dirt game object can give its quests
UPDATE gameobject_template SET flags = 0 WHERE entry = 20985;

-- Quest #27188 What's Haunting Witch Hill?, change to the correct mob for the kill
UPDATE quest_template SET RequiredNpcOrGo1 = 23554 WHERE id = 27188;

-- Update Zelfrax so he can be attacked
UPDATE creature_template SET unit_flags = 32768, unit_flags2 = 2048, npcflag = 0, faction_A = 834, faction_H = 834, lootid = 23864 WHERE entry = 23864;

-- Fix quest 27245: Prisoners of the Grimtotems
SET @NPC := 23720; 
SET @GAMEOBJ := 186287;
UPDATE `gameobject_template` SET `AIName`='SmartGameObjectAI' WHERE `entry` = @GAMEOBJ; 
DELETE FROM `smart_scripts` WHERE `entryorguid` = @GAMEOBJ AND `source_type`=1; 
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, 
`event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, 
`action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
(@GAMEOBJ,1,0,0,70,0,100,0,2,0,0,0,33,@NPC,0,0,0,0,0,7,0,0,0,0,0,0,0,'Blackhoof Cage - On activate - Give credit for quest 27245');

-- Update the blackhoof cage game object so it closes back after 60 seconds
UPDATE gameobject_template SET data2 = 60000 WHERE entry = 186287;

-- Update Balos Jacken so alliance players can get and complete its quests
UPDATE creature_template SET faction_A = 1077, faction_H = 1077 WHERE entry = 5089;

-- Update the item quests for Horde only
UPDATE quest_template SET RequiredRaces = 690 WHERE Id IN (27254, 27255, 27256, 27257, 27260, 27244, 27259);

-- Quest #25479 To New Thalanaar - Autocomplete
update quest_template set SpecialFlags = 0, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id = 25479;

-- Quest #27212 Discrediting the Deserters - Autocomplete
update quest_template set SpecialFlags = 0, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id = 27212;

-- Quest #27336 The Grimtotem Weapon - Set the correct monster for kills
update quest_template set RequiredNpcOrGo1 = 4344 where id = 27336;

-- Quest #27429 Raze Direhorn Post! - Autocomplete
update quest_template set SpecialFlags = 0, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id = 27429;

-- Quest #27291 Peace at Last - Autocomplete
update quest_template set SpecialFlags = 0, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id = 27291;

-- Repair the flight master in mudsprocket
UPDATE creature_template SET gossip_menu_id = 0 WHERE entry = 40358;

-- *** FIXES FOR DUSTWALLOW MARSH END ***


-- *** FIXES FOR TANARIS START ***

-- Quest #25112 - Butcherbot, change the NPC to get the correct kill ID
UPDATE quest_template SET RequiredNpcOrGo1 = 5419 WHERE Id = 25112;

-- Quest #25111 - Scavengers Scavenged, change the NPC to get the correct kill ID
UPDATE quest_template SET RequiredNpcOrGo1 = 5429 WHERE Id = 25111;

-- Quest #25115 - Blisterpaw Butchery, change the NPC to get the correct kill ID
UPDATE quest_template SET RequiredNpcOrGo1 = 5426 WHERE Id = 25115;

-- Quest #24951 - A Great Idea, change the NPC to get the correct kill ID
UPDATE quest_template SET RequiredNpcOrGo1 = 5451 WHERE Id = 24951;

-- Quest #24933 Chicken of the Desert - Add the loot to the NPC
DELETE FROM `creature_loot_template` WHERE `entry` = 5427 AND `item` = 51778;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(5427, 51778, -75, 1, 0, 1, 1);

-- Quest #24953 Just Trying to Kill some bugs - Autocomplete
update quest_template set SpecialFlags = 0, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id = 24953;

-- Spawn the missing NPCs and mobs
DELETE FROM creature WHERE guid >= 601000 and guid <= 601004;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES 
(601000, 39059, 1, 1, 1, 0, 0, -9753.16, -3671.49, 10.8148, 1.89824, 120, 0, 0, 126, 0, 0, 0, 0, 0), -- Kelsey Steelspark
(601001, 39077, 1, 1, 1, 0, 0, -9845.54, -2791.35, 14.7329, 0.0211303, 120, 0, 0, 4276, 0, 0, 0, 0, 0), -- Antechamber Guardian
(601002, 38704, 1, 1, 1, 0, 0, -7945.33, -5272.32, 0.727369, 1.70194, 120, 0, 0, 126, 0, 0, 0, 0, 0), -- Kelsey Steelspark
(601003, 38968, 1, 1, 1, 0, 0, -7453.27, -2881.41, 6.58566, 5.98627, 120, 0, 0, 3000, 0, 0, 0, 0, 0), -- Mazoga
(601004, 40712, 209, 1, 1, 0, 0, 1232.28, 838.796, 8.88742, 6.09942, 120, 0, 0, 1294, 3801, 0, 0, 0, 0); -- Mazoga Spirit

-- Quest #25063 Terrapination - Add the loot to the NPC
DELETE FROM `creature_loot_template` WHERE `entry` = 5431 AND `item` = 52282;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(5431, 52282, -75, 1, 0, 1, 1);

-- Update the item quests for Horde only
UPDATE quest_template SET RequiredRaces = 690 WHERE Id IN (25107, 24905);

-- Update the item quests for Alliance only
UPDATE quest_template SET RequiredRaces = 1101 WHERE Id IN (25421);

-- NPC Mazoga, remove aura so the NPC will be visible
UPDATE creature_template_addon SET auras = '' WHERE entry = 38927;

-- Quest #25021 Blood to Thrive - Add the loot to the NPC
DELETE FROM `creature_loot_template` WHERE `entry` IN (5646, 5647, 5645) AND `item` = 52064;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(5646, 52064, -90, 1, 0, 1, 1),
(5647, 52064, -90, 1, 0, 1, 1),
(5645, 52064, -90, 1, 0, 1, 1);

-- Monster Mazoga must be changed so players can fight him
UPDATE creature_template SET faction_A = 90, faction_H = 90 WHERE entry = 38968;

-- Quest #25032 - Secrets in the Oasis, change the NPC to get the correct kill ID
UPDATE quest_template SET RequiredNpcOrGo1 = 38968 WHERE Id = 25032;

-- NPC Kelsey Steelspark, remove aura so the NPC will be visible
UPDATE creature_template_addon SET auras = '' WHERE entry = 38535;

-- NPC Steamwheedle Survivor must be changed so players can fight him
UPDATE creature_template SET faction_A = 90, faction_H = 90 WHERE entry = 38571;

-- Quest #24910 & 25050 - Rocket Rescue, change the NPC to get the correct kill ID
UPDATE quest_template SET RequiredNpcOrGo1 = 38571 WHERE Id IN (24910, 25050);

-- *** FIXES FOR TANARIS END ***


-- Outland - Quest 9361 - Drop the correct item for cooking quest
UPDATE creature_loot_template SET item = 23248 WHERE item = 23270;

-- Swamp of Sorrows - Quest #27592 Drinks on the Rocks - Silt Crawler needs to drop quest item "Stolen Silversnap Ice"
DELETE FROM `creature_loot_template` WHERE `entry` = 922 AND `item` = 61356;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(922, 61356, -100, 1, 0, 1, 1);

-- Ironforge - Quest 26118 - Seize the ambassador - Autocomplete
update quest_template set Flags = 65536, SpecialFlags = 0, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id = 26118;

-- Add the Undead mounts to the vendor so starting undead can also have their mounts
DELETE FROM npc_vendor WHERE entry = 33996 AND item = 46308;
INSERT INTO npc_vendor (entry, slot, item, maxcount, incrtime, ExtendedCost, type) VALUES (33996, 30, 46308, 0, 0, 0, 1);
DELETE FROM npc_vendor WHERE entry = 33996 AND item = 47101;
INSERT INTO npc_vendor (entry, slot, item, maxcount, incrtime, ExtendedCost, type) VALUES (33996, 31, 47101, 0, 0, 0, 1);


-- *** FIXES FOR ELWYNN FOREST ***

-- Quest 29082 & 28811 & 28806 - Fear No Evil (3 versions) - Autocomplete
update quest_template set SpecialFlags = 0, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id IN (29082, 28811, 28806);

-- Quest 26917 - The hunter's path - Can be done only by Hunter
update quest_template set RequiredClasses = 4 WHERE id = 26917;

-- Quest 26914 - Immolation - Can be done only by Warlock
update quest_template set RequiredClasses = 256 WHERE id = 26914;

-- Quest 26913 - Charging into battle - Can be done only by Warrior
update quest_template set RequiredClasses = 1 WHERE id = 26913;

-- Quest 26918 - The Power of the Light - Can be done only by Paladin
update quest_template set RequiredClasses = 2 WHERE id = 26918;

-- Quest 26919 - Healing the Wounded - Can be done only by Priest
update quest_template set RequiredClasses = 16 WHERE id = 26919;

-- Quest 26916 - Mastering the Arcane - Can be done only by Mage
update quest_template set RequiredClasses = 128 WHERE id = 26916;

-- Update the class quests in Elwynn forest so they autocomplete
update quest_template set SpecialFlags = 0, RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id IN (26917, 26914, 26913, 26918, 26919, 26916);

-- Quest 28757 - Beating Them Back - Can be done only by Human Mage
update quest_template set RequiredClasses = 128, RequiredRaces = 1 WHERE id = 28757;

-- Quest 28762 - Beating Them Back - Can be done only by Human Paladin
update quest_template set RequiredClasses = 2, RequiredRaces = 1 WHERE id = 28762;

-- Quest 28763 - Beating Them Back - Can be done only by Human Priest
update quest_template set RequiredClasses = 16, RequiredRaces = 1 WHERE id = 28763;

-- Quest 28764 - Beating Them Back - Can be done only by Human Rogue
update quest_template set RequiredClasses = 8, RequiredRaces = 1 WHERE id = 28764;

-- Quest 28765 - Beating Them Back - Can be done only by Human Warlock
update quest_template set RequiredClasses = 256, RequiredRaces = 1 WHERE id = 28765;

-- Quest 28766 - Beating Them Back - Can be done only by Human Warrior
update quest_template set RequiredClasses = 1, RequiredRaces = 1 WHERE id = 28766;

-- Quest 28767 - Beating Them Back - Can be done only by Human Hunter
update quest_template set RequiredClasses = 4, RequiredRaces = 1 WHERE id = 28767;

-- Quest 28767 - Beating Them Back - Can be done only by Human Hunter
update quest_template set RequiredClasses = 4, RequiredRaces = 1 WHERE id = 28767;

-- Quest 29078 - Beating Them Back - Can be done only by Non Humans
update quest_template set RequiredRaces = 1100 WHERE id = 29078;

-- Quest 29079 - Lions for Lambs - Can be done only by Non Humans
update quest_template set RequiredRaces = 1100 WHERE id = 29079;

-- Quest Lions for Lambs - These quests can only be done by Humans
update quest_template set RequiredRaces = 1 WHERE id IN (28759, 28769, 28770, 28771, 28772, 28773, 28774);

-- Elwynn Forest Quest Chain - Fix the quest flags so they follow the correct chain
update quest_template set PrevQuestId = 0, ExclusiveGroup = 0 where id = 28757;
update quest_template set PrevQuestId = 0, ExclusiveGroup = 0 where id = 28767;
update quest_template set PrevQuestId = 0, ExclusiveGroup = 0 where id = 28762;
update quest_template set PrevQuestId = 0, ExclusiveGroup = 0 where id = 28763;
update quest_template set PrevQuestId = 0, ExclusiveGroup = 0 where id = 28764;
update quest_template set PrevQuestId = 0, ExclusiveGroup = 0 where id = 28765;
update quest_template set PrevQuestId = 0, ExclusiveGroup = 0 where id = 28766;
update quest_template set PrevQuestId = 0, ExclusiveGroup = 0 where id = 29078;
-- Second quest
update quest_template set PrevQuestId = 28757, ExclusiveGroup = 0 where id = 28769;
update quest_template set PrevQuestId = 28767, ExclusiveGroup = 0 where id = 28759;
update quest_template set PrevQuestId = 28762, ExclusiveGroup = 0 where id = 28770;
update quest_template set PrevQuestId = 28763, ExclusiveGroup = 0 where id = 28771;
update quest_template set PrevQuestId = 28764, ExclusiveGroup = 0 where id = 28772;
update quest_template set PrevQuestId = 28765, ExclusiveGroup = 0 where id = 28773;
update quest_template set PrevQuestId = 28766, ExclusiveGroup = 0 where id = 28774;
update quest_template set PrevQuestId = 29078, ExclusiveGroup = 0 where id = 29079;
-- Third quest
update quest_template set PrevQuestId = 28759, ExclusiveGroup = 0 where id = 26910;
update quest_template set PrevQuestId = 28769, ExclusiveGroup = 0 where id = 3104;
update quest_template set PrevQuestId = 28770, ExclusiveGroup = 0 where id = 3101;
update quest_template set PrevQuestId = 28771, ExclusiveGroup = 0 where id = 3103;
update quest_template set PrevQuestId = 28772, ExclusiveGroup = 0 where id = 3102;
update quest_template set PrevQuestId = 28773, ExclusiveGroup = 0 where id = 3105;
update quest_template set PrevQuestId = 28774, ExclusiveGroup = 0 where id = 3100;
update quest_template set PrevQuestId = 29079, ExclusiveGroup = 0 where id = 29080;
-- Fourth quest
update quest_template set PrevQuestId = 3100, ExclusiveGroup = 0 where id = 26913;
update quest_template set PrevQuestId = 3101, ExclusiveGroup = 0 where id = 26918;
update quest_template set PrevQuestId = 3102, ExclusiveGroup = 0 where id = 26915;
update quest_template set PrevQuestId = 3103, ExclusiveGroup = 0 where id = 26919;
update quest_template set PrevQuestId = 3104, ExclusiveGroup = 0 where id = 26916;
update quest_template set PrevQuestId = 3105, ExclusiveGroup = 0 where id = 26914;
update quest_template set PrevQuestId = 26910, ExclusiveGroup = 0 where id = 26917;
update quest_template set PrevQuestId = 29080, ExclusiveGroup = 0 where id = 29081;
-- Fifth quest
update quest_template set PrevQuestId = 26913, ExclusiveGroup = 0 where id = 28789;
update quest_template set PrevQuestId = 26914, ExclusiveGroup = 0 where id = 28788;
update quest_template set PrevQuestId = 26915, ExclusiveGroup = 0 where id = 28787;
update quest_template set PrevQuestId = 26916, ExclusiveGroup = 0 where id = 28784;
update quest_template set PrevQuestId = 26917, ExclusiveGroup = 0 where id = 28780;
update quest_template set PrevQuestId = 26918, ExclusiveGroup = 0 where id = 28785;
update quest_template set PrevQuestId = 26919, ExclusiveGroup = 0 where id = 28786;
update quest_template set PrevQuestId = 29081, ExclusiveGroup = 0 where id = 29083;
-- Sixth quest
update quest_template set PrevQuestId = 28780, ExclusiveGroup = 0 where id = 28791;
update quest_template set PrevQuestId = 28784, ExclusiveGroup = 0 where id = 28792;
update quest_template set PrevQuestId = 28785, ExclusiveGroup = 0 where id = 28793;
update quest_template set PrevQuestId = 28786, ExclusiveGroup = 0 where id = 28794;
update quest_template set PrevQuestId = 28787, ExclusiveGroup = 0 where id = 28795;
update quest_template set PrevQuestId = 28788, ExclusiveGroup = 0 where id = 28796;
update quest_template set PrevQuestId = 28789, ExclusiveGroup = 0 where id = 28797;
update quest_template set PrevQuestId = 29083, ExclusiveGroup = 0 where id = 26389;
-- Seventh quest
update quest_template set PrevQuestId = 26389, ExclusiveGroup = 0 where id = 26390;
update quest_template set PrevQuestId = 28791, ExclusiveGroup = 0, NextQuestIDChain = 0 where id = 28817;
update quest_template set PrevQuestId = 28792, ExclusiveGroup = 0, NextQuestIDChain = 0 where id = 28818;
update quest_template set PrevQuestId = 28793, ExclusiveGroup = 0, NextQuestIDChain = 0 where id = 28819;
update quest_template set PrevQuestId = 28794, ExclusiveGroup = 0, NextQuestIDChain = 0 where id = 28820;
update quest_template set PrevQuestId = 28795, ExclusiveGroup = 0, NextQuestIDChain = 0 where id = 28821;
update quest_template set PrevQuestId = 28796, ExclusiveGroup = 0, NextQuestIDChain = 0 where id = 28822;
update quest_template set PrevQuestId = 28797, ExclusiveGroup = 0, NextQuestIDChain = 0 where id = 28823;
-- Eight quest
update quest_template set PrevQuestId = 26390, ExclusiveGroup = 0 where id = 54;
update quest_template set PrevQuestId = 0, ExclusiveGroup = 0 where id = 26389;

-- These creatures should not give quests, they are the objectives of the quests
DELETE FROM creature_questrelation WHERE id IN (49871, 49874, 50047, 42940);

-- Fear no Evil - This quest should only be given once
DELETE FROM creature_questrelation WHERE quest IN (28806, 28808, 28809, 28810, 28811, 28812, 28813);

-- Wanted Poster needs to be selectable
UPDATE gameobject_template SET flags = 0 WHERE entry = 68;

-- Sentinel Hill Guard - Remove incorrect auras
UPDATE creature_template_addon SET auras = '' WHERE entry = 42407;

-- Extinguishing Hope - Made by Bootz
DELETE FROM`conditions` WHERE`SourceTypeOrReferenceId`= 13 AND`SourceEntry` IN (80208);
INSERT INTO`conditions` (`SourceTypeOrReferenceId`, `SourceGroup`, `SourceEntry`, `ElseGroup`, `ConditionTypeOrReference`, `ConditionValue1`, `ConditionValue2`, `ConditionValue3`, `ErrorTextId`, `ScriptName`, `Comment`) VALUES
(13, 0, 80208, 0, 18, 1, 42940, 0, 0, '', 'Spray Water'); -- "Spray Water" requires target"Northshire Vineyards Fire Trigger"

-- Northshire Vineyards Fire Trigger - Made by Bootz
SET@ENTRY:= 42940;
SET@SOURCETYPE:= 0;
DELETE FROM`smart_scripts` WHERE `entryorguid`= @ENTRY AND`source_type`= @SOURCETYPE;
UPDATE `creature_template` SET `AIName`= 'SmartAI' WHERE `entry`= @ENTRY LIMIT 1;
INSERT INTO`smart_scripts` (`entryorguid`,`source_type`,`id`,`link`,`event_type`,`event_phase_mask`,`event_chance`,`event_flags`,`event_param1`,`event_param2`,`event_param3`,`event_param4`,`action_type`,`action_param1`,`action_param2`,`action_param3`,`action_param4`,`action_param5`,`action_param6`,`target_type`,`target_param1`,`target_param2`,`target_param3`,`target_x`,`target_y`,`target_z`,`target_o`,`comment`) VALUES
(@ENTRY,@SOURCETYPE,0,0,25,0,100,0,0,0,0,0,22,1,0,0,0,0,0,1,0,0,0,0.0,0.0,0.0,0.0,"Northshire Vineyards Fire Trigger - SetEventPhase_1 on Reset"),
(@ENTRY,@SOURCETYPE,1,0,23,1,100,0,80175,0,0,0,11,80175,0,0,0,0,0,1,0,0,0,0.0,0.0,0.0,0.0,"Northshire Vineyards Fire Trigger - Cast_Vineyard Fire"),
(@ENTRY,@SOURCETYPE,2,3,8,1,100,0,80208,0,0,0,33,42940,0,0,0,0,0,7,0,0,0,0.0,0.0,0.0,0.0,"Northshire Vineyards Fire Trigger - Give Kill Credit on SpellHit_Spray Water"),
(@ENTRY,@SOURCETYPE,3,0,61,1,100,0,0,0,0,0,22,2,0,0,0,0,0,1,0,0,0,0.0,0.0,0.0,0.0,"Northshire Vineyards Fire Trigger - SetEventPhase_2"),
(@ENTRY,@SOURCETYPE,4,0,8,2,100,0,80208,0,1000,1000,37,80223,0,0,0,0,0,1,0,0,0,0.0,0.0,0.0,0.0,"Northshire Vineyards Fire Trigger - Die on SpellHit_Spray Water");

-- *** FIXES FOR ELWYNN FOREST END ***


-- Update the game object template so these items are selectable
UPDATE `gameobject_template` SET `flags`=0 WHERE `entry` IN (55, 56, 61, 259, 261, 2083, 2688, 2701, 4141, 7510, 7923, 32569, 131474, 138492, 142151, 152097, 176392, 179485, 179517, 179880, 180025, 180503, 181698, 181748, 184300, 184825, 185165, 186585, 188085, 190777, 191760, 191761, 191766, 192060, 195676, 201742, 202135, 202264, 202335, 202697, 202701, 202706, 202712, 202714, 202859, 203134, 203140, 204817, 205207, 205874, 207104, 207125, 207406, 207407, 207408, 207409, 207410, 207411, 207412, 208420, 208549, 208550, 208825);
UPDATE `gameobject_template` SET `flags`=32 WHERE `entry` IN (2702, 187565, 188419, 190535, 190602, 190657, 190917, 192079, 192080, 192524, 195497, 195517, 195600, 202613, 202759, 202916, 202975, 203301, 203305, 203395, 204959, 205350, 206585);

-- Orgrimar + Gnomeragan Elevator fix
UPDATE `gameobject_template` SET `flags`=40 WHERE `entry` IN (206609, 206610, 206608, 196837, 207889, 152614, 203716, 205079);
DELETE FROM `gameobject` WHERE `guid` IN (884, 47997, 886, 48000, 885, 48001, 875, 48005, 878, 48004);
INSERT INTO `gameobject` (`guid`, `id`, `map`, `spawnMask`, `phaseMask`, `position_x`, `position_y`, `position_z`, `orientation`, `rotation0`, `rotation1`, `rotation2`, `rotation3`, `spawntimesecs`, `animprogress`, `state`) VALUES
(884, 206609, 1, 1, 1, 1902.046, -4373.103, 43.99677, 5.707206, 0, 0, 0.9563048, -0.2923717, 120, 255, 1),
(886, 206610, 1, 1, 1, 1755.314, -4396.597, 42.34779, 3.744939, 0, 0, 0.9563048, -0.2923717, 120, 255, 1),
(885, 206608, 1, 1, 1, 1704.782, -4265.96, 34.88367, 3.976283, 0, 0, 0.9563048, -0.2923717, 120, 255, 1),
(875, 196837, 1, 1, 1, 3218.322, -4502.832, 266.3751, 1.570796, 0, 0, 0.7071069, 0.7071066, 120, 255, 1),
(878, 207889, 1, 1, 1, 2936.059, -4993.609, 126.7327, 6.051209, 0, 0, 1, -4.371139E-08, 120, 255, 1),
(47997, 152614, 1, 1, 1, 2263.702, -5565.56, 33.93858, 5.183629, 0, 0, -0.5224984, 0.8526402, 120, 255, 1);

-- Throne of the Tides Elevator Fix
DELETE FROM `gameobject` WHERE `guid` = 200291;
INSERT INTO `gameobject` (`guid`, `id`, `map`, `spawnMask`, `phaseMask`, `position_x`, `position_y`, `position_z`, `orientation`, `rotation0`, `rotation1`, `rotation2`, `rotation3`, `spawntimesecs`, `animprogress`, `state`) VALUES
(200291, 207209, 643, 3, 1, -215.916, 805.182, 253.9, 3.10993, 0, 0, 0.999875, 0.0158323, 86400, 0, 1);

-- Thunder Bluff Elevator Fix
UPDATE `gameobject_template` SET type=11, displayId=360, name='Mesa Elevator', faction=0, flags=40, size=1, questItem1=0, questItem2=0, questItem3=0, questItem4=0, questItem5=0, questItem6=0, data0=0, data1=0, data2=0, data3=0, data4=0, data5=0, data6=0, data7=0, data8=0, data9=0, data10=0, data11=0, data12=0, data13=0, data14=0, data15=0, data16=0, data17=0, data18=0, data19=0, data20=0, data21=0, data22=0, data23=0 WHERE entry='4171';UPDATE `gameobject_template` SET type=11, displayId=360, name='Mesa Elevator', faction=0, flags=40, size=1, questItem1=0, questItem2=0, questItem3=0, questItem4=0, questItem5=0, questItem6=0, data0=0, data1=0, data2=0, data3=0, data4=0, data5=0, data6=0, data7=0, data8=0, data9=0, data10=0, data11=0, data12=0, data13=0, data14=0, data15=0, data16=0, data17=0, data18=0, data19=0, data20=0, data21=0, data22=0, data23=0 WHERE entry='4170';
UPDATE `gameobject_template` SET type=11, displayId=360, name='Mesa Elevator', faction=0, flags=40, size=1, questItem1=0, questItem2=0, questItem3=0, questItem4=0, questItem5=0, questItem6=0, data0=0, data1=0, data2=0, data3=0, data4=0, data5=0, data6=0, data7=0, data8=0, data9=0, data10=0, data11=0, data12=0, data13=0, data14=0, data15=0, data16=0, data17=0, data18=0, data19=0, data20=0, data21=0, data22=0, data23=0 WHERE entry='47297';UPDATE `gameobject_template` SET type=11, displayId=360, name='Mesa Elevator', faction=0, flags=40, size=1, questItem1=0, questItem2=0, questItem3=0, questItem4=0, questItem5=0, questItem6=0, data0=0, data1=0, data2=0, data3=0, data4=0, data5=0, data6=0, data7=0, data8=0, data9=0, data10=0, data11=0, data12=0, data13=0, data14=0, data15=0, data16=0, data17=0, data18=0, data19=0, data20=0, data21=0, data22=0, data23=0 WHERE entry='47296';

-- Stonetalon Mountains and Azshara Elevator Fix
UPDATE `gameobject_template` SET type=11, displayId=360, name='Mesa Elevator', faction=0, flags=40, size=1, questItem1=0, questItem2=0, questItem3=0, questItem4=0, questItem5=0, questItem6=0, data0=0, data1=0, data2=0, data3=0, data4=0, data5=0, data6=0, data7=0, data8=0, data9=0, data10=0, data11=0, data12=0, data13=0, data14=0, data15=0, data16=0, data17=0, data18=0, data19=0, data20=0, data21=0, data22=0, data23=0 WHERE entry='11899';UPDATE `gameobject_template` SET type=11, displayId=360, name='Mesa Elevator', faction=0, flags=40, size=1, questItem1=0, questItem2=0, questItem3=0, questItem4=0, questItem5=0, questItem6=0, data0=0, data1=0, data2=0, data3=0, data4=0, data5=0, data6=0, data7=0, data8=0, data9=0, data10=0, data11=0, data12=0, data13=0, data14=0, data15=0, data16=0, data17=0, data18=0, data19=0, data20=0, data21=0, data22=0, data23=0 WHERE entry='11898';
UPDATE `gameobject_template` SET type=11, displayId=9693, name='Doodad_Goblin_elevator01', faction=0, flags=40, size=1, questItem1=0, questItem2=0, questItem3=0, questItem4=0, questItem5=0, questItem6=0, data0=0, data1=0, data2=0, data3=0, data4=0, data5=0, data6=0, data7=0, data8=0, data9=0, data10=0, data11=0, data12=0, data13=0, data14=0, data15=0, data16=0, data17=0, data18=0, data19=0, data20=0, data21=0, data22=0, data23=0 WHERE entry='204243';UPDATE `gameobject_template` SET type=11, displayId=9693, name='Doodad_Goblin_elevator01', faction=0, flags=40, size=1, questItem1=0, questItem2=0, questItem3=0, questItem4=0, questItem5=0, questItem6=0, data0=0, data1=0, data2=0, data3=0, data4=0, data5=0, data6=0, data7=0, data8=0, data9=0, data10=0, data11=0, data12=0, data13=0, data14=0, data15=0, data16=0, data17=0, data18=0, data19=0, data20=0, data21=0, data22=0, data23=0 WHERE entry='204245';
UPDATE `gameobject_template` SET type=11, displayId=9693, name='Doodad_Goblin_elevator01', faction=0, flags=40, size=1, questItem1=0, questItem2=0, questItem3=0, questItem4=0, questItem5=0, questItem6=0, data0=0, data1=0, data2=0, data3=0, data4=0, data5=0, data6=0, data7=0, data8=0, data9=0, data10=0, data11=0, data12=0, data13=0, data14=0, data15=0, data16=0, data17=0, data18=0, data19=0, data20=0, data21=0, data22=0, data23=0 WHERE entry='204244';UPDATE `gameobject_template` SET type=11, displayId=9693, name='Doodad_Goblin_elevator01', faction=0, flags=40, size=1, questItem1=0, questItem2=0, questItem3=0, questItem4=0, questItem5=0, questItem6=0, data0=0, data1=0, data2=0, data3=0, data4=0, data5=0, data6=0, data7=0, data8=0, data9=0, data10=0, data11=0, data12=0, data13=0, data14=0, data15=0, data16=0, data17=0, data18=0, data19=0, data20=0, data21=0, data22=0, data23=0 WHERE entry='204246';

-- Vendor Sognar Cliffbeard needs to sell Bag o' Sheep Innards
DELETE FROM npc_vendor WHERE entry = 5124 AND item = 69984;
INSERT INTO npc_vendor (entry, slot, item, maxcount, incrtime, ExtendedCost, type) VALUES 
(5124, 13, 69984, 0, 0, 0, 1);

-- Update the dun morogh chicken so they can be attacked and they give the cooking quest loot
UPDATE creature_template SET unit_flags = 0, unit_flags2 = 2048, lootid = 53568 WHERE entry = 53568;
DELETE FROM `creature_loot_template` WHERE `entry` = 53568 AND `item` = 69982;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(53568, 69982, -100, 1, 0, 1, 1);

-- The Imported Supplies needs to contain Cocoa Beans
DELETE FROM `item_loot_template` WHERE `entry` = 68689 AND `item` = 62786;
INSERT INTO `item_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(68689, 62786, 100, 1, 0, 5, 20);

-- Quest 29356 - I need a favor to cask, clear the second objective so it can be completed, old value was 53574
UPDATE quest_template SET RequiredNpcOrGo1 = -208872, RequiredNpcOrGoCount1 = 1, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0 WHERE id = 29356;

-- Narkk NPC needs to sell it's stuff, old gossip_menu_id was 11743
UPDATE creature_template SET gossip_menu_id = 0 WHERE entry = 2663;

-- Hide the object and the creature near the portals in Stormwind because they bug the game
UPDATE gameobject SET position_z = -119.896 WHERE guid = 45948;
UPDATE creature SET position_z = -119.579 WHERE guid = 30674;

-- Create the portal to Ironforge/Darnassus/Exodar in Stormwind and the portals to go back to stormwind
DELETE FROM gameobject WHERE guid >= 598000 AND guid <= 598005;
INSERT INTO gameobject (guid, id, map, spawnMask, phaseMask, position_x, position_y, position_z, orientation, rotation0, rotation1, rotation2, rotation3, spawntimesecs, animprogress, state) VALUES 
(598000, 176497, 0, 1, 1, -8204.41, 398.62, 117.28, 2.14, 0, 0, 0, 1, 120, 255, 1),
(598001, 207996, 0, 1, 1, -8198.29, 401.21, 117.28, 2.03, 0, 0, 0, 1, 120, 255, 1),
(598002, 207995, 0, 1, 1, -8194.43, 406.69, 117.28, 2.16, 0, 0, 0, 1, 120, 255, 1),
(598003, 208227, 530, 1, 1, -4047.69, -11569.55, -138.49, 0, 0, 0, 0, 1, 120, 255, 1),
(598004, 208227, 1, 1, 1, 9662.46, 2515.79, 1331.67, 2.55, 0, 0, 0, 1, 120, 255, 1),
(598005, 208227, 0, 1, 1, -4623.57, -907.97, 501.07, 5.39, 0, 0, 0, 1, 120, 255, 1);

-- Update the ironforge portal game object
UPDATE gameobject_template SET faction = 1732, data2 = 0 WHERE entry = 176497;

-- Spawn the missing NPCs in Stormwind
DELETE FROM creature WHERE guid >= 601005 and guid <= 601005;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES 
(601005, 8666, 0, 1, 1, 0, 0, -8717.36, 649.01, 100.68, 0.24, 120, 0, 0, 1294, 3801, 0, 0, 0, 0); -- Lil Timmy

-- Quest #29316 Back to Basics - Darnassus - Autocomplete
UPDATE quest_template SET RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0 WHERE Id = 29316;

-- Quest #361 is flagged as Depreceated, the item that gives it should not drop anymore
DELETE FROM creature_loot_template WHERE item = 2839;

-- Update the stormwind crabs so they can be attacked and they give the cooking quest loot
UPDATE creature_template SET unit_flags = 0, unit_flags2 = 2048, lootid = 42339 WHERE entry = 42339;
DELETE FROM `creature_loot_template` WHERE `entry` = 42339 AND `item` = 57175;
INSERT INTO `creature_loot_template` (`entry`, `item`, `ChanceOrQuestChance`, `lootmode`, `groupid`, `mincountOrRef`, `maxcount`) VALUES 
(42339, 57175, -100, 1, 0, 1, 1);

-- Spawn the missing flight masters in the Searing Gorge and a vendor in Dun Morogh
DELETE FROM creature WHERE guid >= 601006 and guid <= 601008;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES 
(601006, 2941, 0, 1, 1, 0, 1, -6559.99, -1168.48, 309.828, 6.1657, 300, 0, 0, 232470, 0, 0, 0, 0, 0), -- Lanie Reed <Gryphon Master>
(601007, 3305, 0, 1, 1, 0, 1, -6559.42, -1104.02, 310.272, 0.5461, 300, 0, 0, 232470, 0, 0, 0, 0, 0), -- Grisha <Wind Rider Master>
(601008, 1263, 0, 1, 1, 0, 0, -5524.42, -1315.21, 402.261, 3.9399, 300, 0, 0, 42, 0, 0, 0, 0, 0); -- Yarlyn Amberstill

-- *** TOL BARAD FIX START ***

-- Tol Barad - Quest #27992 Magnets, How Do They Work? - Add the Siege Scrap
DELETE FROM gameobject WHERE guid >= 600987 AND guid <= 600994;
INSERT INTO gameobject (guid, id, map, spawnMask, phaseMask, position_x, position_y, position_z, orientation, rotation0, rotation1, rotation2, rotation3, spawntimesecs, animprogress, state) VALUES 
(600987, 206644, 732, 1, 1, -495.21, 1516.41, 18.87, 0, 0, 0, 0, 1, 120, 0, 1),
(600988, 206644, 732, 1, 1, -476.03, 1555.22, 20.74, 0, 0, 0, 0, 1, 120, 0, 1),
(600989, 206644, 732, 1, 1, -449.76, 1592.10, 22.10, 0, 0, 0, 0, 1, 120, 0, 1),
(600990, 206644, 732, 1, 1, -413.09, 1634.74, 18.42, 0, 0, 0, 0, 1, 120, 0, 1),
(600991, 206644, 732, 1, 1, -361.21, 1691.63, 18.64, 0, 0, 0, 0, 1, 120, 0, 1),
(600992, 206644, 732, 1, 1, -346.63, 1605.44, 23.09, 0, 0, 0, 0, 1, 120, 0, 1),
(600993, 206644, 732, 1, 1, -370.19, 1567.54, 17.98, 0, 0, 0, 0, 1, 120, 0, 1),
(600994, 206644, 732, 1, 1, -379.87, 1599.92, 20.94, 0, 0, 0, 0, 1, 120, 0, 1);

-- Quest 28065 - Walk a mile in their shoes - The quest doesn't work so we change it temporarly to kill the NPC we need to escort
UPDATE quest_template SET SpecialFlags = 1, Flags = 4232, RequiredNpcOrGo1 = 48308, RequiredNpcOrGoCount1 = 1, ObjectiveText1 = 'Farson Hold Prisoner Slain', EndText = '', QuestGiverTextWindow = '', QuestGiverTargetName = '' WHERE Id = 28065;
UPDATE creature_template SET faction_A = 190, faction_H = 190 WHERE entry = 48308;
UPDATE `creature_template` SET `AIName`= 'SmartAI' WHERE `entry`= 47240;
DELETE FROM `smart_scripts` WHERE `entryorguid` = 47240;
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, `event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, `action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES
(47240, 0, 0, 0, 19,  0, 100, 0, 28065, 0, 0, 0, 15, 28065, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 'Commander Marcus - On Quest Accept - Call Areaexplored');

-- Quest 28275 - Bombs Away! - The quest doesn't work so we change it temporarly to kill the NPC next to cannon instead of the ships
UPDATE quest_template SET RequiredNpcOrGo1 = 46630, RequiredNpcOrGoCount1 = 5, ObjectiveText1 = 'Accursed Longshoreman Slain' WHERE Id = 28275;

-- *** TOL BARAD FIX END ***


-- *** DEADMINES FIX START ***

-- Deadmines locked door doesn't open so we move it out of the way - Original position was 7.41049 - 
UPDATE gameobject SET position_z = -107.41049 WHERE id = 16397;

-- Captain Cookie - Old unit_flags was 33587264, we need to change it so the creature can be killed
UPDATE creature_template SET unit_flags = 0 WHERE entry = 47739;

-- Spawn the missing NPC: "Captain" Cookie <Defias Kingpin?>
DELETE FROM creature WHERE guid >= 601009 and guid <= 601009;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES 
(601009, 47739, 36, 1, 1, 0, 0, -63.6964, -820.163, 41.2095, 3.15336, 300, 0, 0, 10680, 0, 0, 0, 0, 0); 

-- *** DEADMINES FIX END ***
