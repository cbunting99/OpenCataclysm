-- Quest 14125 - Name: 447 - Remove the last objective, it cannot be done
update quest_template set RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0 WHERE id = 14125;

-- change partygoers so they can be attacked
update creature_template set faction_A = 7, faction_H = 7, npcflag = 2, unit_flags = 32768 WHERE entry = 35175;

-- change defiant troll so they can be attacked
update creature_template set faction_A = 7, faction_H = 7, npcflag = 2, unit_flags = 32768 WHERE entry = 34830;

-- kajamite chunk needs to be selectable
update gameobject_template set flags = 0, data14 = 0 where entry = 195492;

-- spawn some kajamite chunk 
DELETE FROM gameobject WHERE guid >= 600200 AND guid <= 600214;
INSERT INTO gameobject (guid, id, map, spawnMask, phaseMask, position_x, position_y, position_z, orientation, rotation0, rotation1, rotation2, rotation3, spawntimesecs, animprogress, state) VALUES 
(600200, 195492, 648, 1, 1, -8490.12, 1142.11, 41.02, 0.66, 0, 0, 0, 1, 120, 255, 1),
(600201, 195492, 648, 1, 1, -8506.02, 1178.39, 46.18, 0.71, 0, 0, 0, 1, 120, 255, 1),
(600202, 195492, 648, 1, 1, -8522.49, 1223.33, 52.94, 0.28, 0, 0, 0, 1, 120, 255, 1),
(600203, 195492, 648, 1, 1, -8489.81, 1252.36, 54.14, 4.43, 0, 0, 0, 1, 120, 255, 1),
(600204, 195492, 648, 1, 1, -8455.17, 1157.93, 39.74, 5.80, 0, 0, 0, 1, 120, 255, 1),
(600205, 195492, 648, 1, 1, -8452.51, 1175.44, 41.11, 4.03, 0, 0, 0, 1, 120, 255, 1),
(600206, 195492, 648, 1, 1, -8430.61, 1215.54, 45.90, 3.72, 0, 0, 0, 1, 120, 255, 1),
(600207, 195492, 648, 1, 1, -8426.38, 1165.03, 40.36, 2.63, 0, 0, 0, 1, 120, 255, 1),
(600208, 195492, 648, 1, 1, -8410.07, 1154.99, 39.40, 0.54, 0, 0, 0, 1, 120, 255, 1),
(600209, 195492, 648, 1, 1, -8362.90, 1154.08, 34.93, 4.62, 0, 0, 0, 1, 120, 255, 1),
(600210, 195492, 648, 1, 1, -8347.58, 1112.10, 30.12, 2.41, 0, 0, 0, 1, 120, 255, 1),
(600211, 195492, 648, 1, 1, -8371.38, 1118.47, 33.71, 0.52, 0, 0, 0, 1, 120, 255, 1),
(600212, 195492, 648, 1, 1, -8504.54, 1087.44, 42.45, 0.47, 0, 0, 0, 1, 120, 255, 1),
(600213, 195492, 648, 1, 1, -8495.78, 1063.05, 41.92, 2.31, 0, 0, 0, 1, 120, 255, 1),
(600214, 195492, 648, 1, 1, -8533.05, 1043.69, 41.82, 1.07, 0, 0, 0, 1, 120, 255, 1);

-- Quest 14071 - Rolling with my homies - Autocomplete
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0 WHERE id = 14071;

-- Many creatures and quest givers
DELETE FROM creature WHERE guid >= 600200 and guid <= 600299;
INSERT INTO creature (guid, id, map, spawnMask, phaseMask, modelid, equipment_id, position_x, position_y, position_z, orientation, 
spawntimesecs, spawndist, currentwaypoint, curhealth, curmana, MovementType, npcflag, unit_flags, dynamicflags) VALUES 
(600200, 37602, 648, 1, 1, 0, 0, -8420.62, 1323.53, 102.038, 1.65794, 300, 0, 0, 102, 0, 0, 0, 0, 0),
(600201, 35175, 648, 1, 1, 0, 1, -8467.6, 1324.62, 102.534, 2.62398, 300, 0, 0, 42, 0, 0, 0, 0, 0),
(600202, 35175, 648, 1, 1, 0, 1, -8474.85, 1321.88, 102.154, 1.92497, 300, 0, 0, 42, 0, 0, 0, 0, 0),
(600203, 35175, 648, 1, 1, 0, 1, -8486.15, 1322.25, 102.154, 1.44588, 300, 0, 0, 42, 0, 0, 0, 0, 0),
(600204, 35175, 648, 1, 1, 0, 1, -8497.07, 1327.94, 102.533, 0.32276, 300, 0, 0, 42, 0, 0, 0, 0, 0),
(600205, 35175, 648, 1, 1, 0, 1, -8497.73, 1342.75, 102.533, 0.279563, 300, 0, 0, 42, 0, 0, 0, 0, 0),
(600206, 35175, 648, 1, 1, 0, 1, -8497.57, 1357.1, 102.533, 6.23288, 300, 0, 0, 42, 0, 0, 0, 0, 0),
(600207, 35175, 648, 1, 1, 0, 1, -8487.21, 1363.22, 102.53, 5.22365, 300, 0, 0, 42, 0, 0, 0, 0, 0),
(600208, 35175, 648, 1, 1, 0, 1, -8479.27, 1364.05, 102.531, 4.61104, 300, 0, 0, 42, 0, 0, 0, 0, 0),
(600209, 35175, 648, 1, 1, 0, 1, -8467.81, 1356.75, 102.533, 3.71176, 300, 0, 0, 42, 0, 0, 0, 0, 0),
(600210, 35175, 648, 1, 1, 0, 1, -8467.66, 1341.05, 102.533, 3.4251, 300, 0, 0, 42, 0, 0, 0, 0, 0),
(600211, 35200, 648, 1, 1, 0, 1, -8444.64, 1340.78, 102.002, 3.857, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600212, 35200, 648, 1, 1, 0, 1, -8445.51, 1353.78, 101.928, 3.29152, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600213, 35200, 648, 1, 1, 0, 1, -8445.72, 1374.4, 102.768, 3.50358, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600214, 35200, 648, 1, 1, 0, 1, -8455.26, 1391.18, 102.968, 3.96303, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600215, 35200, 648, 1, 1, 0, 1, -8475.27, 1392.01, 102.571, 4.61491, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600216, 35200, 648, 1, 1, 0, 1, -8499.42, 1392.79, 102.21, 4.96049, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600217, 35200, 648, 1, 1, 0, 1, -8519, 1391.07, 102.743, 5.65164, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600218, 35200, 648, 1, 1, 0, 1, -8524.82, 1363.91, 102.142, 6.24069, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600219, 35200, 648, 1, 1, 0, 1, -8526.93, 1342, 102.028, 0.0988784, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600220, 35200, 648, 1, 1, 0, 1, -8526.15, 1317.45, 102.213, 0.4955, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600221, 35200, 648, 1, 1, 0, 1, -8510.64, 1291.76, 101.89, 1.75214, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600222, 35200, 648, 1, 1, 0, 1, -8480.61, 1289.95, 102.468, 1.56757, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600223, 35200, 648, 1, 1, 0, 1, -8455.49, 1298.95, 101.955, 2.12519, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600224, 39615, 648, 1, 1, 0, 1, -8423.62, 1362.23, 116.861, 1.52837, 300, 0, 0, 49130, 44540, 0, 0, 0, 0),
(600225, 35234, 648, 1, 1, 0, 1, -8097.45, 1570.77, 8.84087, 3.19722, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600226, 35234, 648, 1, 1, 0, 1, -8154.83, 1570.24, 19.0756, 2.23118, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600227, 35234, 648, 1, 1, 0, 1, -8096.53, 1642.24, 9.48048, 3.15795, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600228, 35234, 648, 1, 1, 0, 1, -8156.75, 1643.09, 19.4997, 4.00225, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600229, 35234, 648, 1, 1, 0, 1, -8216.33, 1644.18, 32.7282, 5.55341, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600230, 35234, 648, 1, 1, 0, 1, -8210.08, 1574.66, 31.6483, 4.76801, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600231, 35234, 648, 1, 1, 0, 1, -8253.1, 1525.72, 42.4036, 4.1122, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600232, 35234, 648, 1, 1, 0, 1, -8299.83, 1528.15, 45.3876, 5.00756, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600233, 35234, 648, 1, 1, 0, 1, -8339.14, 1521.18, 48.9719, 5.75922, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600234, 35234, 648, 1, 1, 0, 1, -8356.66, 1503.76, 46.2434, 0.0218828, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600235, 35234, 648, 1, 1, 0, 1, -8318.76, 1464.9, 45.473, 0.414589, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600236, 35234, 648, 1, 1, 0, 1, -8276.08, 1441.55, 39.5472, 1.33743, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600237, 35234, 648, 1, 1, 0, 1, -8227.05, 1457.38, 39.6306, 3.18704, 300, 0, 0, 71, 0, 0, 0, 0, 0),
(600238, 36403, 648, 1, 1, 0, 1, -7885.63, 1833.63, 4.32754, 3.10701, 300, 0, 0, 49130, 44540, 0, 0, 134250496, 0);


-- Quest 24502 - Necessary Roughness - Autocomplete
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0 WHERE id = 24502;
DELETE FROM creature_involvedrelation WHERE id = 37106 AND quest = 24502;
INSERT INTO creature_involvedrelation (id, quest) VALUES (37106, 24502);

-- Quest 28414 - Fourth and Goal - Autocomplete
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0 WHERE id = 28414;

-- Quest 14122 - The Great Bank Heist - Autocomplete
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id = 14122;

-- Quest 26712 - Off to the bank - Hide quest, it's duplicated
update quest_template set Level = 90, MinLevel = 90 WHERE id = 26711;
update quest_template set Level = 1, MinLevel = 1 WHERE id = 26712;

-- Quest 14110 - The new you - Autocomplete, the vendors don't sell the items
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id = 14110;
update quest_template set RequiredNpcOrGo1 = 0, RequiredNpcOrGoCount1 = 0, RequiredNpcOrGo2 = 0, RequiredNpcOrGoCount2 = 0, RequiredNpcOrGo3 = 0, RequiredNpcOrGoCount3 = 0, RequiredNpcOrGo4 = 0, RequiredNpcOrGoCount4 = 0, RequiredItemId1 = 0, RequiredItemCount1 = 0, RequiredItemId2 = 0, RequiredItemCount2 = 0, RequiredItemId3 = 0, RequiredItemCount3 = 0, RequiredItemId4 = 0, RequiredItemCount4 = 0 WHERE id = 14109;

-- Quest 14109 - The new you - Hide quest, it's duplicated
update quest_template set Level = 90, MinLevel = 90 WHERE id = 14110;
update quest_template set Level = 1, MinLevel = 1 WHERE id = 14109;

-- Quest 14123, the 3 game objects needs to be selectable to get the items from them and complete the quest
update gameobject_template set flags = 0, data0 = 43, data14 = 0, data3 = 1  where entry = 195515; -- Maldy's Falcon 
update gameobject set id = 195515 where id = 195522;
update gameobject_template set flags = 0, data0 = 43, data14 = 0, data3 = 1 where entry = 195516; -- The Goblin Lisa
update gameobject set id = 195516 where id = 195523;
update gameobject_template set flags = 0, data0 = 43, data14 = 0, data3 = 1 where entry = 195518; -- The Ultimate Bomb
update gameobject set id = 195518 where id = 195524;

-- Change the NPC so the quest can be completed correctly
update creature_involvedrelation set id = 39615 where id = 35222 and quest = 14116;
update creature_involvedrelation set id = 36403 where id = 35222 and quest = 14126;
update creature_template set npcflag = 3 where entry in (39615, 36403);

-- Quest #14126 - Life Saving - When the quest ends, warp to Durotar
SET @NPC := 36403; 
SET @QUEST := 14126;
UPDATE `creature_template` SET `AIName`='SmartAI' WHERE `entry` = @NPC; 
DELETE FROM `smart_scripts` WHERE `entryorguid` = @NPC AND `source_type`=0; 
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, 
`event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, 
`action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES 
(@NPC, 0, 0, 0, 20, 0, 100, 0, @QUEST, 0, 0, 0, 62, 1, 0, 0, 0, 0, 0, 0, 8, 0, 0, 1440.86, -5019.81, 12.03, 1.68, 'Teleport to Durotar');

-- Update the horde quests to include Goblins
UPDATE quest_template SET RequiredRaces = 946 WHERE RequiredRaces = 690;

-- Add the Goblin trike and turbo trike to the vendor in Orgrimar so goblins can also have mounts
DELETE FROM npc_vendor WHERE entry = 45546 AND item = 62461;
INSERT INTO npc_vendor (entry, slot, item, maxcount, incrtime, ExtendedCost, type) VALUES (45546, 23, 62461, 0, 0, 0, 1);
DELETE FROM npc_vendor WHERE entry = 45546 AND item = 62462;
INSERT INTO npc_vendor (entry, slot, item, maxcount, incrtime, ExtendedCost, type) VALUES (45546, 24, 62462, 0, 0, 0, 1);


