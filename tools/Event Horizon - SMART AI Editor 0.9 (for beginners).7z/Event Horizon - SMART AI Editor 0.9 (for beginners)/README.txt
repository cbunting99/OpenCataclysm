----------------------------------------------
EVENT HORIZON - SAI EDITOR
Version 		0.9
Released 		Jul_20_2011
----------------------------------------------

Event Horizon is a development tool for SmartAI (SAI) which allows you to easily manage smartAI scripts.
It is was initially written for TrinityCore and Project Skyfire but it can work on any other core which supports smartAI.]

If you need any help or tutorials visit:
http://devsource-eventhorizon.tk/  	(temporary)

(or) email me at:
devsource.tk@gmail.com

----------------------------------------------

Required Softwares:
- Java 2 SE Runtime Environment (www.java.com)

----------------------------------------------